# ShapeScan — Angle Detector & Shape Designer

A full-stack web app for scanning shapes, measuring angles, designing polygons with real-world measurements, and exporting to SVG and DXF.

## Features
- **Scan tab** — Upload a photo and auto-detect shape edges and angles
- **Draw tab** — Click to add points, drag to move, live angle display; shape templates; real-world scale (imperial/metric); seam allowance tabs; photo background overlay; zoom/pan
- **Library tab** — Save shapes per user account; organize into project folders; export as SVG or DXF

## Tech Stack
- **Frontend:** React + Vite + TypeScript + Tailwind CSS + shadcn/ui
- **Backend:** Express.js (Node.js)
- **Database:** SQLite via better-sqlite3 + Drizzle ORM
- **Auth:** Session-based (express-session), numeric PIN password (≥5 digits)

## Local Development

```bash
npm install
npm run dev
```

Opens at http://localhost:5000

## Deploy to Railway (recommended)

1. Push this folder to a GitHub repo
2. Go to https://railway.app → New Project → Deploy from GitHub
3. Railway auto-detects Node.js. Set the start command to:
   ```
   npm run build && npm start
   ```
4. Railway gives you a public URL instantly. Add a custom domain in Settings if desired.

## Deploy to Render

1. Push to GitHub
2. Go to https://render.com → New Web Service → connect repo
3. Build command: `npm run build`
4. Start command: `npm start`
5. Free tier available (spins down after inactivity)

## Environment

No environment variables required for basic operation. The SQLite database (`data.db`) is created automatically on first run.

## Password Rules
- Numeric digits only (0–9)
- Minimum 5 digits
- Example: `12345`, `99801`

## Export Formats
- **SVG** — Opens in Illustrator, Inkscape, Figma, Cricut, any browser
- **DXF** — AutoCAD R12 format, compatible with AutoCAD, Fusion 360, laser cutters, CNC machines
