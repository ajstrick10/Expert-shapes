import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ── Users ──────────────────────────────────────────────────────────────────
export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),   // stored as plaintext numeric PIN (≥5 digits)
  createdAt: integer("created_at").notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// ── Projects ────────────────────────────────────────────────────────────────
export const projects = sqliteTable("projects", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  userId: integer("user_id").notNull(),
  createdAt: integer("created_at").notNull(),
});

export const insertProjectSchema = createInsertSchema(projects).omit({ id: true });
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// ── Saved Shapes ────────────────────────────────────────────────────────────
export const savedShapes = sqliteTable("saved_shapes", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  vertices: text("vertices").notNull(), // JSON array of {x,y}
  projectId: integer("project_id"),     // null = "All shapes" / no project
  userId: integer("user_id").notNull(),
  createdAt: integer("created_at").notNull(),
});

export const insertSavedShapeSchema = createInsertSchema(savedShapes).omit({ id: true });
export type InsertSavedShape = z.infer<typeof insertSavedShapeSchema>;
export type SavedShape = typeof savedShapes.$inferSelect;
