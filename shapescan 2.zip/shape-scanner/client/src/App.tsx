import { useState, useEffect } from "react";
import { Router, Switch, Route } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import ShapeScanner from "@/pages/ShapeScanner";
import AuthPage from "@/pages/AuthPage";
import NotFound from "@/pages/not-found";

export interface AuthUser {
  id: number;
  username: string;
}

const API_BASE = (window as any).__API_BASE__ ||
  (typeof "__PORT_5000__" === "string" && !"__PORT_5000__".startsWith("__")
    ? "__PORT_5000__"
    : "");

async function checkSession(): Promise<AuthUser | null> {
  try {
    const res = await fetch(`${API_BASE}/api/auth/me`, { credentials: "include" });
    if (!res.ok) return null;
    const ct = res.headers.get("content-type") || "";
    if (!ct.includes("application/json")) return null;
    return await res.json();
  } catch {
    return null;
  }
}

function App() {
  const [user, setUser] = useState<AuthUser | null | undefined>(undefined); // undefined = loading

  // Check existing session on mount
  useEffect(() => {
    checkSession().then(u => setUser(u));
  }, []);

  function handleAuth(u: AuthUser) {
    setUser(u);
    queryClient.clear();
  }

  async function handleLogout() {
    try {
      await fetch(`${API_BASE}/api/auth/logout`, { method: "POST", credentials: "include" });
    } catch { /* ignore */ }
    setUser(null);
    queryClient.clear();
  }

  // Loading state
  if (user === undefined) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 rounded-full border-2 border-indigo-500 border-t-transparent animate-spin" />
          <p className="text-sm text-muted-foreground">Loading…</p>
        </div>
      </div>
    );
  }

  // Not logged in
  if (!user) {
    return (
      <QueryClientProvider client={queryClient}>
        <AuthPage onAuth={handleAuth} />
        <Toaster />
      </QueryClientProvider>
    );
  }

  // Logged in — render main app
  return (
    <QueryClientProvider client={queryClient}>
      <Router hook={useHashLocation}>
        <Switch>
          <Route path="/" component={() => <ShapeScanner user={user} onLogout={handleLogout} />} />
          <Route component={NotFound} />
        </Switch>
      </Router>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
