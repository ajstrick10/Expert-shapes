import { useState, useRef, useCallback, useEffect, useLayoutEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Camera, Upload, ScanLine, Triangle, Square, Pentagon, Hexagon,
  Circle, RefreshCw, Download, Sun, Moon, Ruler, ZoomIn,
  BookMarked, Trash2, Pencil, X, Check, CornerDownRight,
  MousePointer2, ImageIcon, EyeOff, FolderOpen, FolderPlus, Folder, LogOut, User,
} from "lucide-react";
import type { SavedShape, Project } from "@shared/schema";

// ═══════════════════════════════════════════════════════════════
// GEOMETRY HELPERS
// ═══════════════════════════════════════════════════════════════
interface Pt { x: number; y: number }

function dist(a: Pt, b: Pt) {
  return Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2);
}

function angleBetween(a: Pt, b: Pt, c: Pt) {
  const ab = { x: a.x - b.x, y: a.y - b.y };
  const cb = { x: c.x - b.x, y: c.y - b.y };
  const dot = ab.x * cb.x + ab.y * cb.y;
  const cross = ab.x * cb.y - ab.y * cb.x;
  // angle between the two edge vectors (always 0–180)
  return Math.round(Math.atan2(Math.abs(cross), dot) * (180 / Math.PI) * 10) / 10;
}

// Compute the signed area of a polygon (positive = CCW in standard math coords,
// but in canvas coords Y is flipped so positive = CW on screen)
function signedArea(pts: Pt[]) {
  let a = 0;
  for (let i = 0; i < pts.length; i++) {
    const j = (i + 1) % pts.length;
    a += pts[i].x * pts[j].y - pts[j].x * pts[i].y;
  }
  return a / 2; // positive means CW on canvas
}

// Interior angle at vertex b, accounting for polygon winding
function interiorAngle(a: Pt, b: Pt, c: Pt, isCW: boolean) {
  const ab = { x: a.x - b.x, y: a.y - b.y };
  const cb = { x: c.x - b.x, y: c.y - b.y };
  const dot = ab.x * cb.x + ab.y * cb.y;
  const cross = ab.x * cb.y - ab.y * cb.x; // positive = right turn (CW)
  const raw = Math.atan2(Math.abs(cross), dot) * 180 / Math.PI;
  // For CW winding: left turn (cross < 0) means reflex interior angle
  // For CCW winding: right turn (cross > 0) means reflex interior angle
  const isReflex = isCW ? cross < 0 : cross > 0;
  const angle = isReflex ? 360 - raw : raw;
  return Math.round(angle * 10) / 10;
}

function centroid(pts: Pt[]) {
  return {
    x: pts.reduce((s, p) => s + p.x, 0) / pts.length,
    y: pts.reduce((s, p) => s + p.y, 0) / pts.length,
  };
}

// ── outward tab rectangles for each edge ──────────────────────
// Simple rectangles extruded outward — no corner geometry, no miter.
// Returns one 4-point polygon per edge: [a, b, outerB, outerA]
// where outerA/outerB are the two far corners of the rectangle.
function computeTabPolygons(pts: Pt[], tabSize: number): Pt[][] {
  if (pts.length < 2) return [];
  const n = pts.length;

  // Canvas Y is flipped vs math, so signedArea > 0 means CW on screen.
  // Outward normal for CW polygon: RIGHT normal = (ey/len, -ex/len)
  // Outward normal for CCW polygon: LEFT normal  = (-ey/len, ex/len)
  const isCW = signedArea(pts) > 0;

  const tabs: Pt[][] = [];
  const edgeCount = n >= 3 ? n : n - 1; // closed vs open
  for (let i = 0; i < edgeCount; i++) {
    const a = pts[i], b = pts[(i + 1) % n];
    const ex = b.x - a.x, ey = b.y - a.y;
    const len = Math.sqrt(ex * ex + ey * ey) || 1;
    // Outward normal — swapped from old code to actually go outward
    const nx = isCW ?  ey / len : -ey / len;
    const ny = isCW ? -ex / len :  ex / len;
    const outerA: Pt = { x: a.x + nx * tabSize, y: a.y + ny * tabSize };
    const outerB: Pt = { x: b.x + nx * tabSize, y: b.y + ny * tabSize };
    tabs.push([a, b, outerB, outerA]);
  }
  return tabs;
}

// ── Bake tabs into the shape outline ─────────────────────────────
// Merges tab rectangles into the polygon, producing a new polygon
// whose boundary IS the outer tab perimeter.
// Layout per tab: [a, b, outerB, outerA]
// The merged outline walks:  outerA[i] → outerB[i]  (outer edge of each tab)
// then fills the corner gap with the shared vertex pts[(i+1)%n]
// between consecutive tabs (since tabs are plain rectangles with no miter).
function bakeTabsIntoShape(pts: Pt[], tabSize: number): Pt[] {
  if (pts.length < 3) return pts;
  const tabs = computeTabPolygons(pts, tabSize);
  const n = pts.length;
  const merged: Pt[] = [];
  for (let i = 0; i < n; i++) {
    const tab = tabs[i];
    // tab = [a, b, outerB, outerA]
    const outerA = tab[3]; // far corner at vertex i
    const outerB = tab[2]; // far corner at vertex i+1
    merged.push(outerA);
    merged.push(outerB);
    // Corner gap between this tab's outerB and next tab's outerA:
    // insert the original shared vertex (the shape corner) so the
    // polygon stays connected without overlap or gap.
    const cornerPt = pts[(i + 1) % n];
    merged.push(cornerPt);
  }
  return merged;
}

// ── Stretch a single edge to a target pixel length ───────────────
// Moves ONLY the two endpoints of edge[edgeIdx] outward/inward
// along the edge direction so it reaches targetPx.
// The midpoint of the edge stays fixed; all other vertices stay put.
// This lets you independently set each side — e.g. turn a square
// into a rectangle by setting two parallel edges to different lengths.
function stretchEdge(pts: Pt[], edgeIdx: number, targetPx: number): Pt[] {
  if (pts.length < 2) return pts;
  const n = pts.length;
  const ai = edgeIdx, bi = (edgeIdx + 1) % n;
  const a = pts[ai], b = pts[bi];
  const currentPx = dist(a, b);
  if (currentPx < 0.5) return pts;
  // Unit vector along the edge
  const ux = (b.x - a.x) / currentPx;
  const uy = (b.y - a.y) / currentPx;
  // Midpoint stays fixed; each endpoint moves half the delta
  const half = (targetPx - currentPx) / 2;
  const newPts = pts.map(p => ({ ...p }));
  newPts[ai] = { x: a.x - ux * half, y: a.y - uy * half };
  newPts[bi] = { x: b.x + ux * half, y: b.y + uy * half };
  return newPts;
}

function polygonArea(pts: Pt[]) {
  let a = 0;
  for (let i = 0; i < pts.length; i++) {
    const j = (i + 1) % pts.length;
    a += pts[i].x * pts[j].y - pts[j].x * pts[i].y;
  }
  return Math.abs(a / 2);
}

function polygonPerimeter(pts: Pt[]) {
  let p = 0;
  for (let i = 0; i < pts.length; i++) p += dist(pts[i], pts[(i + 1) % pts.length]);
  return p;
}

function computeAngles(pts: Pt[]): number[] {
  if (pts.length < 3) return [];
  return pts.map((_, i) => {
    const prev = pts[(i - 1 + pts.length) % pts.length];
    const curr = pts[i];
    const next = pts[(i + 1) % pts.length];
    return angleBetween(prev, curr, next);
  });
}

function shapeName(sides: number) {
  switch (sides) {
    case 3: return "Triangle";
    case 4: return "Quadrilateral";
    case 5: return "Pentagon";
    case 6: return "Hexagon";
    case 7: return "Heptagon";
    case 8: return "Octagon";
    case 9: return "Nonagon";
    case 10: return "Decagon";
    default: return sides > 10 ? "Polygon" : "Shape";
  }
}

// ═══════════════════════════════════════════════════════════════
// SCALE / REAL-WORLD UNIT HELPERS
// ═══════════════════════════════════════════════════════════════
type UnitMode = "px" | "imperial" | "metric";

// Parse a user-typed real-world value into base units (inches or mm)
// Imperial: accepts "18", "1.5", "1'6", "1'6\"", "18in", "18\""
// Metric: accepts "450", "45cm", "0.45m"
function parseRealValue(raw: string, mode: UnitMode): number | null {
  if (mode === "px") return null;
  const s = raw.trim().replace(/,/g, "");
  if (!s) return null;
  if (mode === "imperial") {
    // feet + inches:  1'6  |  1'6"  |  1ft 6in  |  1.5ft
    const ftIn = s.match(/^([\d.]+)'\s*([\d.]*)"?$/);
    if (ftIn) return parseFloat(ftIn[1]) * 12 + (parseFloat(ftIn[2]) || 0);
    const ftOnly = s.match(/^([\d.]+)\s*(?:ft|')$/);
    if (ftOnly) return parseFloat(ftOnly[1]) * 12;
    const inOnly = s.match(/^([\d.]+)\s*(?:in|")?$/);
    if (inOnly) return parseFloat(inOnly[1]);
    return null;
  } else {
    // metric: mm / cm / m
    const m = s.match(/^([\d.]+)\s*(m|cm|mm)?$/);
    if (!m) return null;
    const v = parseFloat(m[1]);
    const u = (m[2] || "mm").toLowerCase();
    if (u === "m")  return v * 1000;
    if (u === "cm") return v * 10;
    return v; // mm
  }
}

// Format a raw px distance into a display string
function fmtDist(px: number, mode: UnitMode, pxPerUnit: number | null): string {
  if (mode === "px" || !pxPerUnit || pxPerUnit <= 0) return `${Math.round(px)}px`;
  const real = px / pxPerUnit;
  if (mode === "imperial") {
    const totalIn = real;
    const ft = Math.floor(totalIn / 12);
    const inch = totalIn - ft * 12;
    if (ft === 0) return `${inch % 1 === 0 ? inch.toFixed(0) : inch.toFixed(2)}"`;
    if (inch < 0.005) return `${ft}'`;
    return `${ft}' ${inch % 1 === 0 ? inch.toFixed(0) : inch.toFixed(2)}"`;
  } else {
    // metric
    if (real >= 1000) return `${(real / 1000).toFixed(3).replace(/\.?0+$/, "")} m`;
    if (real >= 10)   return `${(real / 10).toFixed(1).replace(/\.?0+$/, "")} cm`;
    return `${real.toFixed(1).replace(/\.?0+$/, "")} mm`;
  }
}

// Format area in appropriate units^2
function fmtArea(px2: number, mode: UnitMode, pxPerUnit: number | null): string {
  if (mode === "px" || !pxPerUnit || pxPerUnit <= 0) return `${Math.round(px2).toLocaleString()} px²`;
  const real2 = px2 / (pxPerUnit * pxPerUnit);
  if (mode === "imperial") {
    const sqFt = real2 / 144;
    if (sqFt >= 1) return `${sqFt.toFixed(3).replace(/\.?0+$/, "")} ft²`;
    return `${real2.toFixed(2)} in²`;
  } else {
    const sqM = real2 / 1e6;
    if (sqM >= 0.01) return `${sqM.toFixed(4).replace(/\.?0+$/, "")} m²`;
    const sqCm = real2 / 100;
    if (sqCm >= 1)   return `${sqCm.toFixed(2).replace(/\.?0+$/, "")} cm²`;
    return `${real2.toFixed(1)} mm²`;
  }
}

// ═══════════════════════════════════════════════════════════════
// PRE-MADE SHAPE TEMPLATES
// ═══════════════════════════════════════════════════════════════
function regularPolygon(n: number, r: number, cx: number, cy: number, startAngle = -Math.PI / 2): Pt[] {
  return Array.from({ length: n }, (_, i) => {
    const a = startAngle + (2 * Math.PI * i) / n;
    return { x: Math.round(cx + r * Math.cos(a)), y: Math.round(cy + r * Math.sin(a)) };
  });
}

interface ShapeTemplate { id: string; label: string; icon: string; pts: (cx: number, cy: number, r: number) => Pt[]; }

const SHAPE_TEMPLATES: ShapeTemplate[] = [
  { id: "equilateral", label: "Equilateral Triangle", icon: "△",
    pts: (cx, cy, r) => regularPolygon(3, r, cx, cy) },
  { id: "right-triangle", label: "Right Triangle", icon: "◺",
    pts: (cx, cy, r) => [
      { x: cx - r, y: cy + r * 0.7 },
      { x: cx + r, y: cy + r * 0.7 },
      { x: cx - r, y: cy - r * 0.7 },
    ]},
  { id: "square", label: "Square", icon: "□",
    pts: (cx, cy, r) => regularPolygon(4, r, cx, cy, -Math.PI / 4) },
  { id: "rectangle", label: "Rectangle", icon: "▭",
    pts: (cx, cy, r) => [
      { x: cx - r, y: cy - r * 0.55 },
      { x: cx + r, y: cy - r * 0.55 },
      { x: cx + r, y: cy + r * 0.55 },
      { x: cx - r, y: cy + r * 0.55 },
    ]},
  { id: "diamond", label: "Diamond", icon: "◇",
    pts: (cx, cy, r) => regularPolygon(4, r, cx, cy, 0) },
  { id: "pentagon", label: "Pentagon", icon: "⬠",
    pts: (cx, cy, r) => regularPolygon(5, r, cx, cy) },
  { id: "hexagon", label: "Hexagon", icon: "⬡",
    pts: (cx, cy, r) => regularPolygon(6, r, cx, cy, 0) },
  { id: "octagon", label: "Octagon", icon: "⯃",
    pts: (cx, cy, r) => regularPolygon(8, r, cx, cy, 0) },
  { id: "star5", label: "5-Point Star", icon: "★",
    pts: (cx, cy, r) => {
      const inner = r * 0.4;
      return Array.from({ length: 10 }, (_, i) => {
        const a = -Math.PI / 2 + (Math.PI * i) / 5;
        const rad = i % 2 === 0 ? r : inner;
        return { x: Math.round(cx + rad * Math.cos(a)), y: Math.round(cy + rad * Math.sin(a)) };
      });
    }},
  { id: "star6", label: "6-Point Star", icon: "✶",
    pts: (cx, cy, r) => {
      const inner = r * 0.5;
      return Array.from({ length: 12 }, (_, i) => {
        const a = -Math.PI / 2 + (Math.PI * i) / 6;
        const rad = i % 2 === 0 ? r : inner;
        return { x: Math.round(cx + rad * Math.cos(a)), y: Math.round(cy + rad * Math.sin(a)) };
      });
    }},
  { id: "arrow", label: "Arrow", icon: "➤",
    pts: (cx, cy, r) => [
      { x: Math.round(cx - r),       y: Math.round(cy - r * 0.28) },
      { x: Math.round(cx + r * 0.1), y: Math.round(cy - r * 0.28) },
      { x: Math.round(cx + r * 0.1), y: Math.round(cy - r * 0.65) },
      { x: Math.round(cx + r),       y: Math.round(cy) },
      { x: Math.round(cx + r * 0.1), y: Math.round(cy + r * 0.65) },
      { x: Math.round(cx + r * 0.1), y: Math.round(cy + r * 0.28) },
      { x: Math.round(cx - r),       y: Math.round(cy + r * 0.28) },
    ]},
  { id: "cross", label: "Plus / Cross", icon: "+",
    pts: (cx, cy, r) => {
      const t = r * 0.35;
      return [
        { x: Math.round(cx - t), y: Math.round(cy - r) },
        { x: Math.round(cx + t), y: Math.round(cy - r) },
        { x: Math.round(cx + t), y: Math.round(cy - t) },
        { x: Math.round(cx + r), y: Math.round(cy - t) },
        { x: Math.round(cx + r), y: Math.round(cy + t) },
        { x: Math.round(cx + t), y: Math.round(cy + t) },
        { x: Math.round(cx + t), y: Math.round(cy + r) },
        { x: Math.round(cx - t), y: Math.round(cy + r) },
        { x: Math.round(cx - t), y: Math.round(cy + t) },
        { x: Math.round(cx - r), y: Math.round(cy + t) },
        { x: Math.round(cx - r), y: Math.round(cy - t) },
        { x: Math.round(cx - t), y: Math.round(cy - t) },
      ];
    }},
  { id: "trapezoid", label: "Trapezoid", icon: "⏢",
    pts: (cx, cy, r) => [
      { x: Math.round(cx - r * 0.6), y: Math.round(cy - r * 0.5) },
      { x: Math.round(cx + r * 0.6), y: Math.round(cy - r * 0.5) },
      { x: Math.round(cx + r),       y: Math.round(cy + r * 0.5) },
      { x: Math.round(cx - r),       y: Math.round(cy + r * 0.5) },
    ]},
  { id: "parallelogram", label: "Parallelogram", icon: "▱",
    pts: (cx, cy, r) => [
      { x: Math.round(cx - r * 0.6), y: Math.round(cy - r * 0.5) },
      { x: Math.round(cx + r),       y: Math.round(cy - r * 0.5) },
      { x: Math.round(cx + r * 0.6), y: Math.round(cy + r * 0.5) },
      { x: Math.round(cx - r),       y: Math.round(cy + r * 0.5) },
    ]},
];

// ═══════════════════════════════════════════════════════════════
// SCAN DETECTION
// ═══════════════════════════════════════════════════════════════
interface DetectedShape {
  id: number; name: string; sides: number; angles: number[];
  color: string; vertices: Pt[]; centroid: Pt; area: number; perimeter: number;
}

const PALETTE = [
  "#6366f1","#06b6d4","#10b981","#f59e0b","#ef4444",
  "#8b5cf6","#ec4899","#14b8a6","#f97316","#3b82f6",
];

function perpendicularDist(pt: Pt, l1: Pt, l2: Pt) {
  const dx = l2.x - l1.x, dy = l2.y - l1.y;
  const len = Math.sqrt(dx*dx + dy*dy);
  if (len === 0) return dist(pt, l1);
  return Math.abs((pt.x-l1.x)*dy-(pt.y-l1.y)*dx)/len;
}
function douglasPeucker(pts: Pt[], eps: number): Pt[] {
  if (pts.length <= 2) return pts;
  let maxD = 0, maxI = 0;
  for (let i = 1; i < pts.length-1; i++) {
    const d = perpendicularDist(pts[i], pts[0], pts[pts.length-1]);
    if (d > maxD) { maxD = d; maxI = i; }
  }
  if (maxD > eps) {
    const l = douglasPeucker(pts.slice(0, maxI+1), eps);
    const r = douglasPeucker(pts.slice(maxI), eps);
    return [...l.slice(0,-1), ...r];
  }
  return [pts[0], pts[pts.length-1]];
}
function quadType(angles: number[], pts: Pt[]) {
  const isRect = angles.every(a => Math.abs(a-90)<12);
  const sides = [dist(pts[0],pts[1]),dist(pts[1],pts[2]),dist(pts[2],pts[3]),dist(pts[3],pts[0])];
  const avg = sides.reduce((s,v)=>s+v,0)/4;
  const eq = sides.every(s=>Math.abs(s-avg)/avg<0.15);
  if (isRect && eq) return "Square";
  if (isRect) return "Rectangle";
  if (eq) return "Rhombus";
  const d01=dist(pts[0],pts[1]),d23=dist(pts[2],pts[3]),d12=dist(pts[1],pts[2]),d30=dist(pts[3],pts[0]);
  if (Math.abs(d01-d23)/((d01+d23)/2)<0.15 && Math.abs(d12-d30)/((d12+d30)/2)<0.15) return "Parallelogram";
  return "Quadrilateral";
}
function triType(angles: number[], pts: Pt[]) {
  const sides=[dist(pts[0],pts[1]),dist(pts[1],pts[2]),dist(pts[2],pts[0])];
  const sorted=[...angles].sort((a,b)=>a-b);
  const avg=sides.reduce((a,b)=>a+b,0)/3;
  const eq=sides.every(s=>Math.abs(s-avg)/avg<0.12);
  const iso=sides.filter(s=>Math.abs(s-avg)/avg<0.12).length>=2;
  if (eq) return "Equilateral Triangle";
  if (sorted.some(a=>Math.abs(a-90)<10)) return "Right Triangle";
  if (sorted[2]>90) return "Obtuse Triangle";
  if (iso) return "Isosceles Triangle";
  return "Triangle";
}

function detectShapes(imageData: ImageData, w: number, h: number): DetectedShape[] {
  const { data } = imageData;
  const gray = new Uint8Array(w*h);
  for (let i = 0; i < w*h; i++) gray[i]=Math.round(0.299*data[i*4]+0.587*data[i*4+1]+0.114*data[i*4+2]);
  const blurred = new Uint8Array(w*h);
  const k=[1,2,1,2,4,2,1,2,1];
  for (let y=1;y<h-1;y++) for (let x=1;x<w-1;x++) {
    let s=0;
    for (let ky=-1;ky<=1;ky++) for (let kx=-1;kx<=1;kx++) s+=gray[(y+ky)*w+(x+kx)]*k[(ky+1)*3+(kx+1)];
    blurred[y*w+x]=s>>4;
  }
  const edges=new Uint8Array(w*h);
  for (let y=1;y<h-1;y++) for (let x=1;x<w-1;x++) {
    const gx=-blurred[(y-1)*w+(x-1)]+blurred[(y-1)*w+(x+1)]-2*blurred[y*w+(x-1)]+2*blurred[y*w+(x+1)]-blurred[(y+1)*w+(x-1)]+blurred[(y+1)*w+(x+1)];
    const gy=-blurred[(y-1)*w+(x-1)]-2*blurred[(y-1)*w+x]-blurred[(y-1)*w+(x+1)]+blurred[(y+1)*w+(x-1)]+2*blurred[(y+1)*w+x]+blurred[(y+1)*w+(x+1)];
    edges[y*w+x]=Math.sqrt(gx*gx+gy*gy)>25?255:0;
  }
  const visited=new Uint8Array(w*h);
  const shapes: DetectedShape[]=[];
  const minArea=(w*h)*0.001;
  let colorIdx=0;
  for (let sy=1;sy<h-1;sy++) for (let sx=1;sx<w-1;sx++) {
    const idx=sy*w+sx;
    if (edges[idx]!==255||visited[idx]) continue;
    const pixels: Pt[]=[];
    const queue=[idx];
    visited[idx]=1;
    while (queue.length) {
      const cur=queue.shift()!;
      const cx=cur%w,cy=Math.floor(cur/w);
      pixels.push({x:cx,y:cy});
      for (const [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[1,-1],[-1,1],[1,1]]) {
        const nx=cx+dx,ny=cy+dy;
        if (nx<0||ny<0||nx>=w||ny>=h) continue;
        const ni=ny*w+nx;
        if (edges[ni]===255&&!visited[ni]) { visited[ni]=1; queue.push(ni); }
      }
    }
    if (pixels.length<20) continue;
    const step=Math.max(1,Math.floor(pixels.length/200));
    const sampled=pixels.filter((_,i)=>i%step===0);
    const c=centroid(sampled);
    sampled.sort((a,b)=>Math.atan2(a.y-c.y,a.x-c.x)-Math.atan2(b.y-c.y,b.x-c.x));
    const minX2=Math.min(...sampled.map(p=>p.x)),maxX2=Math.max(...sampled.map(p=>p.x));
    const minY2=Math.min(...sampled.map(p=>p.y)),maxY2=Math.max(...sampled.map(p=>p.y));
    const diag=Math.sqrt((maxX2-minX2)**2+(maxY2-minY2)**2);
    let eps=Math.max(4,diag*0.06);
    let simplified=douglasPeucker([...sampled,sampled[0]],eps).slice(0,-1);
    while (simplified.length>10&&eps<diag*0.25) { eps*=1.5; simplified=douglasPeucker([...sampled,sampled[0]],eps).slice(0,-1); }
    if (simplified.length<3||simplified.length>10) continue;
    const area=polygonArea(simplified);
    if (area<minArea) continue;
    const shC=centroid(simplified);
    if (shapes.some(s=>dist(s.centroid,shC)<Math.sqrt(area)*0.5)) continue;
    const angles=computeAngles(simplified);
    const sides=simplified.length;
    let name=shapeName(sides);
    if (sides===3) name=triType(angles,simplified);
    if (sides===4) name=quadType(angles,simplified);
    shapes.push({ id:shapes.length+1, name, sides, angles, color:PALETTE[colorIdx%PALETTE.length], vertices:simplified, centroid:shC, area:Math.round(area), perimeter:Math.round(polygonPerimeter(simplified)) });
    colorIdx++;
    if (shapes.length>=12) return shapes;
  }
  return shapes;
}

// ═══════════════════════════════════════════════════════════════
// CANVAS DRAW HELPERS
// ═══════════════════════════════════════════════════════════════
function rrect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.arcTo(x+w,y,x+w,y+r,r);
  ctx.lineTo(x+w,y+h-r); ctx.arcTo(x+w,y+h,x+w-r,y+h,r);
  ctx.lineTo(x+r,y+h); ctx.arcTo(x,y+h,x,y+h-r,r);
  ctx.lineTo(x,y+r); ctx.arcTo(x,y,x+r,y,r);
  ctx.closePath();
}

function drawScanOverlay(canvas: HTMLCanvasElement, shapes: DetectedShape[], scale: number, selected: DetectedShape|null) {
  const ctx=canvas.getContext("2d")!;
  ctx.clearRect(0,0,canvas.width,canvas.height);
  shapes.forEach(shape=>{
    const pts=shape.vertices;
    const s=scale;
    const col=selected&&selected.id!==shape.id?shape.color+"55":shape.color;
    ctx.beginPath();
    ctx.moveTo(pts[0].x*s,pts[0].y*s);
    pts.forEach(p=>ctx.lineTo(p.x*s,p.y*s));
    ctx.closePath();
    ctx.fillStyle=col+"22";
    ctx.fill();
    ctx.strokeStyle=col;
    ctx.lineWidth=2.5;
    ctx.stroke();
    pts.forEach(p=>{
      ctx.beginPath();
      ctx.arc(p.x*s,p.y*s,4,0,Math.PI*2);
      ctx.fillStyle=col;
      ctx.fill();
      ctx.strokeStyle="#fff";
      ctx.lineWidth=1.5;
      ctx.stroke();
    });
    pts.forEach((p,i)=>{
      const angle=shape.angles[i];
      const text=`${angle}°`;
      const tx=p.x*s,ty=p.y*s;
      const c2x=shape.centroid.x*s,c2y=shape.centroid.y*s;
      const dx=tx-c2x,dy=ty-c2y;
      const len=Math.sqrt(dx*dx+dy*dy)||1;
      const ox=tx+(dx/len)*18,oy=ty+(dy/len)*18;
      ctx.font="bold 11px 'JetBrains Mono',monospace";
      ctx.textAlign="center";
      ctx.textBaseline="middle";
      const tw=ctx.measureText(text).width+8;
      ctx.fillStyle=col+"ee";
      rrect(ctx,ox-tw/2,oy-8,tw,16,4);
      ctx.fill();
      ctx.fillStyle="#fff";
      ctx.fillText(text,ox,oy);
    });
    const cx=shape.centroid.x*s,cy=shape.centroid.y*s;
    ctx.font="600 12px 'Cabinet Grotesk','Inter',sans-serif";
    ctx.textAlign="center";
    ctx.textBaseline="middle";
    const lw=ctx.measureText(shape.name).width+12;
    ctx.fillStyle="#00000099";
    rrect(ctx,cx-lw/2,cy-10,lw,20,5);
    ctx.fill();
    ctx.fillStyle="#fff";
    ctx.fillText(shape.name,cx,cy);
  });
}

// ═══════════════════════════════════════════════════════════════
// INTERACTIVE DRAW — renders bg image + overlay on one canvas
// ═══════════════════════════════════════════════════════════════
const DRAW_COLOR = "#6366f1";
const POINT_RADIUS = 8;

interface ViewTransform { zoom: number; panX: number; panY: number; }

function drawInteractive(
  canvas: HTMLCanvasElement,
  pts: Pt[],
  isDark: boolean,
  bgImage: HTMLImageElement | null,
  bgOpacity: number,
  hoverIdx: number | null,
  vt: ViewTransform,
  showTabs: boolean,
  tabSize: number,
  unitMode: UnitMode,
  edgePxPerUnit: (number | null)[]
) {
  const ctx = canvas.getContext("2d")!;
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Apply viewport transform (zoom + pan)
  ctx.save();
  ctx.setTransform(vt.zoom, 0, 0, vt.zoom, vt.panX, vt.panY);

  // ── background image ──────────────────────────────────────────
  if (bgImage) {
    ctx.save();
    ctx.globalAlpha = bgOpacity;
    // letterbox-fit into the logical (un-zoomed) canvas space
    const cw = canvas.width / vt.zoom, ch = canvas.height / vt.zoom;
    const iw = bgImage.naturalWidth, ih = bgImage.naturalHeight;
    const imgScale = Math.min(cw / iw, ch / ih);
    const dw = iw * imgScale, dh = ih * imgScale;
    const ox = (cw - dw) / 2, oy = (ch - dh) / 2;
    ctx.drawImage(bgImage, ox, oy, dw, dh);
    ctx.restore();
  }

  if (pts.length === 0) { ctx.restore(); return; }

  const angles = computeAngles(pts);

  // ── polygon fill ──────────────────────────────────────────────
  if (pts.length >= 3) {
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
    ctx.closePath();
    ctx.fillStyle = DRAW_COLOR + "20";
    ctx.fill();
  }

  // ── seam tabs (drawn before main edges so they sit underneath) ─
  if (showTabs && pts.length >= 2) {
    const tabPolys = computeTabPolygons(pts, tabSize);
    tabPolys.forEach(tab => {
      ctx.beginPath();
      ctx.moveTo(tab[0].x, tab[0].y);
      ctx.lineTo(tab[1].x, tab[1].y);
      ctx.lineTo(tab[2].x, tab[2].y);
      ctx.lineTo(tab[3].x, tab[3].y);
      ctx.closePath();
      // semi-transparent amber fill
      ctx.fillStyle = isDark ? "rgba(251,191,36,0.13)" : "rgba(251,191,36,0.18)";
      ctx.fill();
      // dashed outline — U-shape: left side + outer edge + right side
      // tab = [a, b, outerB, outerA]  →  indices 0,1,2,3
      // Draw: a(0)→outerA(3)  then  outerA(3)→outerB(2)  then  outerB(2)→b(1)
      // Do NOT draw a(0)→b(1) — that's the shared polygon edge
      ctx.strokeStyle = "#f59e0b";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([5, 3]);
      ctx.beginPath();
      ctx.moveTo(tab[0].x, tab[0].y);   // a
      ctx.lineTo(tab[3].x, tab[3].y);   // outerA  (left side)
      ctx.lineTo(tab[2].x, tab[2].y);   // outerB  (outer edge)
      ctx.lineTo(tab[1].x, tab[1].y);   // b       (right side)
      ctx.stroke();
      ctx.setLineDash([]);
    });
  }

  // ── edges ─────────────────────────────────────────────────────
  ctx.beginPath();
  ctx.moveTo(pts[0].x, pts[0].y);
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
  if (pts.length >= 3) ctx.closePath();
  ctx.strokeStyle = DRAW_COLOR;
  ctx.lineWidth = 2;
  ctx.setLineDash([]);
  ctx.stroke();

  // ── edge length labels ────────────────────────────────────────
  const edgeCount = pts.length >= 3 ? pts.length : pts.length - 1;
  for (let i = 0; i < edgeCount; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
    const edgeLabel = fmtDist(dist(a, b), unitMode, edgePxPerUnit[i] ?? null);
    ctx.font = "10px 'JetBrains Mono',monospace";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    // small pill bg
    const ew = ctx.measureText(edgeLabel).width + 6;
    ctx.fillStyle = isDark ? "rgba(15,23,42,0.7)" : "rgba(255,255,255,0.8)";
    rrect(ctx, mx - ew/2, my - 12 - 6, ew, 12, 3);
    ctx.fill();
    ctx.fillStyle = isDark ? "#94a3b8" : "#475569";
    ctx.fillText(edgeLabel, mx, my - 12);
  }

  // ── angle arcs + labels ───────────────────────────────────────
  if (pts.length >= 3) {
    angles.forEach((angle, i) => {
      const prev = pts[(i - 1 + pts.length) % pts.length];
      const curr = pts[i];
      const next = pts[(i + 1) % pts.length];

      const v1 = { x: prev.x - curr.x, y: prev.y - curr.y };
      const v2 = { x: next.x - curr.x, y: next.y - curr.y };
      const l1 = Math.sqrt(v1.x**2 + v1.y**2) || 1;
      const l2 = Math.sqrt(v2.x**2 + v2.y**2) || 1;
      const a1 = Math.atan2(v1.y / l1, v1.x / l1);
      const a2 = Math.atan2(v2.y / l2, v2.x / l2);
      const arcR = Math.min(20, Math.min(l1, l2) * 0.3);

      ctx.beginPath();
      ctx.arc(curr.x, curr.y, arcR, a1, a2, false);
      ctx.strokeStyle = DRAW_COLOR + "88";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // label offset toward outside of shape
      const c = centroid(pts);
      const dx = curr.x - c.x, dy = curr.y - c.y;
      const lenC = Math.sqrt(dx**2 + dy**2) || 1;
      const offset = POINT_RADIUS + 24;
      const ox = curr.x + (dx / lenC) * offset;
      const oy = curr.y + (dy / lenC) * offset;

      const text = `${angle}°`;
      ctx.font = "bold 12px 'JetBrains Mono',monospace";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      const tw = ctx.measureText(text).width + 10;
      ctx.fillStyle = DRAW_COLOR + "ee";
      rrect(ctx, ox - tw/2, oy - 9, tw, 18, 5);
      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.fillText(text, ox, oy);
    });

    // centre label
    const c = centroid(pts);
    const name = (() => {
      if (pts.length === 3) return triType(angles, pts);
      if (pts.length === 4) return quadType(angles, pts);
      return shapeName(pts.length);
    })();
    const sum = Math.round(angles.reduce((a, b) => a + b, 0));
    const label = `${name}  ·  Σ${sum}°`;
    ctx.font = "600 12px 'Cabinet Grotesk','Inter',sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const lw = ctx.measureText(label).width + 16;
    ctx.fillStyle = isDark ? "rgba(15,23,42,0.88)" : "rgba(30,27,75,0.88)";
    rrect(ctx, c.x - lw/2, c.y - 11, lw, 22, 6);
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.fillText(label, c.x, c.y);
  }

  // ── vertex dots ───────────────────────────────────────────────
  pts.forEach((p, i) => {
    const isHovered = hoverIdx === i;
    const r = isHovered ? POINT_RADIUS + 3 : POINT_RADIUS;

    // glow ring when hovered
    if (isHovered) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, r + 5, 0, Math.PI * 2);
      ctx.fillStyle = DRAW_COLOR + "30";
      ctx.fill();
    }

    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
    ctx.fillStyle = DRAW_COLOR;
    ctx.fill();
    ctx.strokeStyle = "#fff";
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.font = `bold ${isHovered ? 10 : 9}px sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "#fff";
    ctx.fillText(String(i + 1), p.x, p.y);
  });

  // Restore viewport transform
  ctx.restore();
}

// ═══════════════════════════════════════════════════════════════
// LIBRARY THUMBNAIL
// ═══════════════════════════════════════════════════════════════
function LibraryThumbnail({ vertices, color = DRAW_COLOR }: { vertices: Pt[]; color?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useLayoutEffect(() => {
    const canvas = ref.current;
    if (!canvas || vertices.length < 3) return;
    const W = canvas.width, H = canvas.height;
    const ctx = canvas.getContext("2d")!;
    ctx.clearRect(0, 0, W, H);
    const xs = vertices.map(p => p.x), ys = vertices.map(p => p.y);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);
    const pad = 8;
    const sx = (W - pad*2) / (maxX - minX || 1);
    const sy = (H - pad*2) / (maxY - minY || 1);
    const s = Math.min(sx, sy);
    const offX = (W - (maxX - minX)*s) / 2 - minX*s;
    const offY = (H - (maxY - minY)*s) / 2 - minY*s;
    ctx.beginPath();
    ctx.moveTo(vertices[0].x*s+offX, vertices[0].y*s+offY);
    vertices.forEach(p => ctx.lineTo(p.x*s+offX, p.y*s+offY));
    ctx.closePath();
    ctx.fillStyle = color + "22";
    ctx.fill();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.stroke();
  }, [vertices, color]);
  return <canvas ref={ref} width={80} height={80} className="rounded-lg flex-shrink-0" />;
}

// ═══════════════════════════════════════════════════════════════
// SHAPE ICON
// ═══════════════════════════════════════════════════════════════
function ShapeIcon({ sides }: { sides: number }) {
  if (sides === 3) return <Triangle className="w-4 h-4" />;
  if (sides === 4) return <Square className="w-4 h-4" />;
  if (sides === 5) return <Pentagon className="w-4 h-4" />;
  if (sides === 6) return <Hexagon className="w-4 h-4" />;
  return <Circle className="w-4 h-4" />;
}

// ═══════════════════════════════════════════════════════════════
// EXPORT HELPERS
// ═══════════════════════════════════════════════════════════════

/** Export a shape as an SVG file. Normalises vertices to start at (0,0). */
function exportSVG(name: string, vertices: Pt[]) {
  if (vertices.length < 2) return;

  // Bounding box → translate so min x/y = 0, add 10px padding
  const PAD = 10;
  const xs = vertices.map(p => p.x);
  const ys = vertices.map(p => p.y);
  const minX = Math.min(...xs);
  const minY = Math.min(...ys);
  const maxX = Math.max(...xs);
  const maxY = Math.max(...ys);
  const W = maxX - minX + PAD * 2;
  const H = maxY - minY + PAD * 2;

  const pts = vertices.map(p => `${(p.x - minX + PAD).toFixed(3)},${(p.y - minY + PAD).toFixed(3)}`).join(" ");

  const svg = [
    `<?xml version="1.0" encoding="UTF-8"?>`,
    `<svg xmlns="http://www.w3.org/2000/svg" width="${W.toFixed(3)}" height="${H.toFixed(3)}" viewBox="0 0 ${W.toFixed(3)} ${H.toFixed(3)}">`,
    `  <title>${name}</title>`,
    `  <polygon`,
    `    points="${pts}"`,
    `    fill="none"`,
    `    stroke="#000000"`,
    `    stroke-width="1"`,
    `  />`,
    `</svg>`,
  ].join("\n");

  const blob = new Blob([svg], { type: "image/svg+xml" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${name.replace(/[^a-zA-Z0-9_-]/g, "_")}.svg`;
  a.click();
  URL.revokeObjectURL(url);
}

/**
 * Export a shape as a DXF (AutoCAD R12 ASCII) file.
 * Uses a LWPOLYLINE entity — opens in Illustrator, Inkscape, AutoCAD, Fusion 360, etc.
 */
function exportDXF(name: string, vertices: Pt[]) {
  if (vertices.length < 2) return;

  // DXF coords: Y axis is flipped vs canvas — negate Y so the shape isn't upside-down
  const ys = vertices.map(p => p.y);
  const maxY = Math.max(...ys);

  // Build LWPOLYLINE vertex entries
  const vertexLines = vertices.map(p => [
    " 10",   // X
    p.x.toFixed(6),
    " 20",   // Y (flipped)
    (maxY - p.y).toFixed(6),
  ].join("\n")).join("\n");

  const closed = 1; // closed polygon flag

  const dxf = [
    "0", "SECTION",
    "2", "HEADER",
    "9", "$ACADVER",
    "1", "AC1009",   // AutoCAD R12 — widest compatibility
    "0", "ENDSEC",
    "0", "SECTION",
    "2", "ENTITIES",
    "0", "LWPOLYLINE",
    "8", "0",       // layer 0
    "70", String(closed),
    "90", String(vertices.length),
    vertexLines,
    "0", "ENDSEC",
    "0", "EOF",
  ].join("\n");

  const blob = new Blob([dxf], { type: "application/dxf" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${name.replace(/[^a-zA-Z0-9_-]/g, "_")}.dxf`;
  a.click();
  URL.revokeObjectURL(url);
}

// ═══════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════════════
interface ShapeScannerProps {
  user: { id: number; username: string };
  onLogout: () => void;
}

export default function ShapeScanner({ user, onLogout }: ShapeScannerProps) {
  const [dark, setDark] = useState(() => window.matchMedia("(prefers-color-scheme: dark)").matches);
  const [mainTab, setMainTab] = useState<"scan" | "draw" | "library">("scan");

  // ── Scan state ────────────────────────────────────────────────
  const [scanTab, setScanTab] = useState<"upload" | "camera">("upload");
  const [shapes, setShapes] = useState<DetectedShape[]>([]);
  const [scanning, setScanning] = useState(false);
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [selectedShape, setSelectedShape] = useState<DetectedShape | null>(null);
  const [draggingZone, setDraggingZone] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [displayScale, setDisplayScale] = useState(1);

  const imgRef = useRef<HTMLImageElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // ── Draw state ────────────────────────────────────────────────
  const [drawPts, setDrawPts] = useState<Pt[]>([]);
  const [draggingIdx, setDraggingIdx] = useState<number | null>(null);
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [saveName, setSaveName] = useState("");
  const [uniformScale, setUniformScale] = useState(false);  // when true, dragging scales all pts from centroid
  const [templateOpen, setTemplateOpen] = useState(false);
  const [showTabs, setShowTabs] = useState(false);           // seam allowance tabs
  const [tabSize, setTabSize] = useState(30);                // tab depth in px (always px internally)
  const [tabRealValue, setTabRealValue] = useState("");      // user-typed real-world tab depth (e.g. "1in", "25mm")

  // ── Scale / real-world measurement ───────────────────────────
  // unitMode: "px" = raw pixels (no conversion)
  //           "imperial" = feet & inches  (e.g. 1'-6")
  //           "metric"   = millimetres / centimetres / metres
  const [unitMode, setUnitMode] = useState<"px"|"imperial"|"metric">("px");
  // Per-edge real-world values — edgeValues[i] is the typed length for edge i.
  // Each edge independently computes its own px→real unit scale.
  const [edgeValues, setEdgeValues] = useState<string[]>([]);
  // globalScaleRef: px per base unit (inch or mm), established by the first committed
  // edge value. Subsequent committed values resize the shape using this scale.
  // Reset to null when unit mode changes.
  const globalScaleRef = useRef<number | null>(null);
  // Store the original pts at drag start for uniform-scale reference
  const dragStartPts = useRef<Pt[]>([]);
  const dragStartCanvasPos = useRef<Pt>({ x: 0, y: 0 });

  // ── Viewport (zoom + pan) state ───────────────────────────────
  const [viewTransform, setViewTransform] = useState<ViewTransform>({ zoom: 1, panX: 0, panY: 0 });
  const [isPanning, setIsPanning] = useState(false);      // space held or middle-mouse
  const [panStart, setPanStart] = useState<Pt | null>(null);
  const [panOrigin, setPanOrigin] = useState<ViewTransform>({ zoom: 1, panX: 0, panY: 0 });
  const spaceHeld = useRef(false);
  const lastPinchDist = useRef<number | null>(null);

  // background image overlay state
  const [bgImage, setBgImage] = useState<HTMLImageElement | null>(null);
  const [bgOpacity, setBgOpacity] = useState(0.45);
  const [bgLabel, setBgLabel] = useState<string>("");
  const bgFileRef = useRef<HTMLInputElement>(null);

  const drawCanvasRef = useRef<HTMLCanvasElement>(null);
  const drawContainerRef = useRef<HTMLDivElement>(null);

  // ── Library state ─────────────────────────────────────────────
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingName, setEditingName] = useState("");
  // Project state
  const [activeProjectId, setActiveProjectId] = useState<number | "all" | null>("all"); // "all" = all shapes, null = unassigned, number = project id
  const [newProjectName, setNewProjectName] = useState("");
  const [editingProjectId, setEditingProjectId] = useState<number | null>(null);
  const [editingProjectName, setEditingProjectName] = useState("");
  const [saveProjectId, setSaveProjectId] = useState<number | null>(null); // project to save new shape into

  const { toast } = useToast();

  // Dark mode
  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  // Re-draw scan overlay
  useEffect(() => {
    if (!overlayRef.current || shapes.length === 0) return;
    drawScanOverlay(overlayRef.current, shapes, displayScale, selectedShape);
  }, [selectedShape, shapes, displayScale]);

  // One universal scale: globalScaleRef.current = px per base unit (inch or mm).
  // Set when the first edge value is committed. All labels, tabs, and stats use this.
  const edgeCount = drawPts.length >= 3 ? drawPts.length : Math.max(drawPts.length - 1, 0);
  const globalPxPerUnit: number | null = (unitMode !== "px" && globalScaleRef.current)
    ? globalScaleRef.current
    : null;
  // edgePxPerUnit: each slot gets the same global scale (used by canvas draw fn)
  const edgePxPerUnit: (number | null)[] = Array.from({ length: edgeCount }, () => globalPxPerUnit);
  const avgPxPerUnit = globalPxPerUnit;

  // Re-draw interactive canvas
  useEffect(() => {
    const canvas = drawCanvasRef.current;
    if (!canvas) return;
    drawInteractive(canvas, drawPts, dark, bgImage, bgOpacity, hoverIdx, viewTransform, showTabs, tabSize, unitMode, edgePxPerUnit);
  }, [drawPts, dark, bgImage, bgOpacity, hoverIdx, viewTransform, showTabs, tabSize, unitMode, edgePxPerUnit]);

  // Resize draw canvas
  useEffect(() => {
    const container = drawContainerRef.current;
    const canvas = drawCanvasRef.current;
    if (!container || !canvas) return;
    const ro = new ResizeObserver(() => {
      canvas.width = container.clientWidth;
      canvas.height = container.clientHeight;
      drawInteractive(canvas, drawPts, dark, bgImage, bgOpacity, hoverIdx, viewTransform, showTabs, tabSize, unitMode, edgePxPerUnit);
    });
    ro.observe(container);
    return () => ro.disconnect();
  }, [drawPts, dark, bgImage, bgOpacity, hoverIdx, viewTransform, showTabs, tabSize, unitMode, edgePxPerUnit]);

  // ── API ───────────────────────────────────────────────────────
  const { data: projects = [] } = useQuery<Project[]>({ queryKey: ["/api/projects"] });

  // Shapes filtered by active project — encode filter in the URL so default queryFn handles parsing
  const shapesUrl = activeProjectId === "all"
    ? "/api/shapes"
    : activeProjectId === null
    ? "/api/shapes?projectId=null"
    : `/api/shapes?projectId=${activeProjectId}`;
  const { data: library = [] } = useQuery<SavedShape[]>({
    queryKey: [shapesUrl],
  });

  // All shapes for the count badge
  const { data: allShapes = [] } = useQuery<SavedShape[]>({ queryKey: ["/api/shapes"] });

  const saveMutation = useMutation({
    mutationFn: (body: { name: string; vertices: string; projectId: number | null }) =>
      apiRequest("POST", "/api/shapes", body),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shapes"] });
      queryClient.invalidateQueries({ queryKey: [shapesUrl] });
      setSaveDialogOpen(false);
      setSaveName("");
      toast({ title: "Shape saved to library" });
    },
    onError: (e: Error) => {
      toast({ title: "Failed to save shape", description: e.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/shapes/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shapes"] });
      queryClient.invalidateQueries({ queryKey: [shapesUrl] });
      toast({ title: "Shape removed" });
    },
  });

  const renameMutation = useMutation({
    mutationFn: ({ id, name }: { id: number; name: string }) => apiRequest("PATCH", `/api/shapes/${id}`, { name }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/shapes"] }); setEditingId(null); },
  });

  const moveShapeMutation = useMutation({
    mutationFn: ({ id, projectId }: { id: number; projectId: number | null }) =>
      apiRequest("PATCH", `/api/shapes/${id}`, { projectId }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/shapes"] }); },
  });

  const createProjectMutation = useMutation({
    mutationFn: async (name: string) => {
      const res = await apiRequest("POST", "/api/projects", { name });
      return res.json() as Promise<Project>;
    },
    onSuccess: (data: Project) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setNewProjectName("");
      setActiveProjectId(data.id);
    },
    onError: (e: Error) => {
      toast({ title: "Failed to create project", description: e.message, variant: "destructive" });
    },
  });

  const renameProjectMutation = useMutation({
    mutationFn: ({ id, name }: { id: number; name: string }) => apiRequest("PATCH", `/api/projects/${id}`, { name }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/projects"] }); setEditingProjectId(null); },
  });

  const deleteProjectMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/projects/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/shapes"] });
      setActiveProjectId("all");
    },
  });

  // ── Scan logic ────────────────────────────────────────────────
  const processImage = useCallback((src: string) => {
    setScanning(true); setShapes([]); setSelectedShape(null);
    const img = new Image();
    img.onload = () => {
      const ratio = Math.min(800/img.width, 600/img.height, 1);
      const pW = Math.round(img.width*ratio), pH = Math.round(img.height*ratio);
      const off = document.createElement("canvas");
      off.width=pW; off.height=pH;
      off.getContext("2d")!.drawImage(img,0,0,pW,pH);
      const imageData=off.getContext("2d")!.getImageData(0,0,pW,pH);
      setTimeout(()=>{
        const detected=detectShapes(imageData,pW,pH);
        setShapes(detected); setScanning(false);
        requestAnimationFrame(()=>{
          if (!overlayRef.current||!imgRef.current) return;
          const scale=imgRef.current.clientWidth/pW;
          setDisplayScale(scale);
          overlayRef.current.width=imgRef.current.clientWidth;
          overlayRef.current.height=imgRef.current.clientHeight;
          drawScanOverlay(overlayRef.current, detected, scale, null);
        });
        if (detected.length===0) toast({ title:"No shapes found", description:"Try a clearer image with distinct shapes on a contrasting background." });
        else toast({ title:`${detected.length} shape${detected.length>1?"s":""} detected`, description:"Tap a shape to inspect its angles." });
      },600);
    };
    img.src=src;
  }, [toast]);

  const handleFile = useCallback((file: File)=>{
    if (!file.type.startsWith("image/")) { toast({title:"Invalid file",variant:"destructive"}); return; }
    const reader=new FileReader();
    reader.onload=e=>{ const src=e.target?.result as string; setImageSrc(src); processImage(src); };
    reader.readAsDataURL(file);
  },[processImage,toast]);

  const startCamera = useCallback(async()=>{
    try {
      const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"}});
      streamRef.current=stream;
      if (videoRef.current) { videoRef.current.srcObject=stream; videoRef.current.play(); }
      setCameraActive(true);
    } catch { toast({title:"Camera unavailable",variant:"destructive"}); }
  },[toast]);

  const stopCamera = useCallback(()=>{
    streamRef.current?.getTracks().forEach(t=>t.stop());
    streamRef.current=null; setCameraActive(false);
  },[]);

  const captureCamera=useCallback(()=>{
    if (!videoRef.current) return;
    const v=videoRef.current;
    const c=document.createElement("canvas");
    c.width=v.videoWidth; c.height=v.videoHeight;
    c.getContext("2d")!.drawImage(v,0,0);
    const src=c.toDataURL("image/png");
    stopCamera(); setImageSrc(src); processImage(src);
  },[processImage,stopCamera]);

  const resetScan=useCallback(()=>{ setImageSrc(null); setShapes([]); setSelectedShape(null); setScanning(false); stopCamera(); },[stopCamera]);

  const downloadScan=useCallback(()=>{
    if (!overlayRef.current||!imageSrc) return;
    const c=document.createElement("canvas");
    const img=imgRef.current!;
    c.width=img.clientWidth; c.height=img.clientHeight;
    const ctx=c.getContext("2d")!;
    ctx.drawImage(img,0,0,c.width,c.height);
    ctx.drawImage(overlayRef.current,0,0);
    const a=document.createElement("a"); a.download="shape-scan.png"; a.href=c.toDataURL(); a.click();
  },[imageSrc]);

  // ── Background image loader for Draw tab ──────────────────────
  const handleBgFile = useCallback((file: File) => {
    if (!file.type.startsWith("image/")) return;
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { setBgImage(img); setBgLabel(file.name); };
    img.src = url;
  }, []);

  const clearBg = useCallback(() => {
    setBgImage(null); setBgLabel("");
  }, []);

  // ── Draw canvas interactions ───────────────────────────────────

  // Convert screen (CSS pixel) position to canvas logical space
  const screenToCanvas = useCallback((screenX: number, screenY: number): Pt => {
    const vt = viewTransform;
    return { x: (screenX - vt.panX) / vt.zoom, y: (screenY - vt.panY) / vt.zoom };
  }, [viewTransform]);

  // Get raw screen position from event (relative to canvas element)
  const getScreenPos = (e: React.MouseEvent | React.TouchEvent): Pt => {
    const canvas = drawCanvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const clientX = "touches" in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = "touches" in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
    return { x: clientX - rect.left, y: clientY - rect.top };
  };

  const findHitPoint = useCallback((canvasPos: Pt): number => {
    // Hit radius grows with inverse zoom so it stays visually consistent
    const hitR = (POINT_RADIUS + 6) / viewTransform.zoom;
    for (let i = drawPts.length - 1; i >= 0; i--) {
      if (dist(canvasPos, drawPts[i]) <= hitR) return i;
    }
    return -1;
  }, [drawPts, viewTransform]);

  // Keyboard pan mode
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === "Space" && !e.repeat) { spaceHeld.current = true; }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === "Space") { spaceHeld.current = false; setIsPanning(false); setPanStart(null); }
    };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    return () => { window.removeEventListener("keydown", onKeyDown); window.removeEventListener("keyup", onKeyUp); };
  }, []);

  // Scroll-wheel zoom
  const handleCanvasWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const canvas = drawCanvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const delta = e.deltaY < 0 ? 1.1 : 1 / 1.1;
    setViewTransform(prev => {
      const newZoom = Math.min(Math.max(prev.zoom * delta, 0.25), 10);
      // Zoom toward the mouse position
      const newPanX = mx - (mx - prev.panX) * (newZoom / prev.zoom);
      const newPanY = my - (my - prev.panY) * (newZoom / prev.zoom);
      return { zoom: newZoom, panX: newPanX, panY: newPanY };
    });
  }, []);

  const handleCanvasDown = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    const screen = getScreenPos(e);

    // Pinch-to-zoom: two fingers
    if ("touches" in e && e.touches.length === 2) {
      const t0 = e.touches[0], t1 = e.touches[1];
      lastPinchDist.current = Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY);
      return;
    }

    // Pan mode: space held OR middle mouse
    const isMiddle = "button" in e && (e as React.MouseEvent).button === 1;
    if (spaceHeld.current || isMiddle) {
      setIsPanning(true);
      setPanStart(screen);
      setPanOrigin(viewTransform);
      return;
    }

    const canvasPos = screenToCanvas(screen.x, screen.y);
    const hit = findHitPoint(canvasPos);
    if (hit !== -1) {
      setDraggingIdx(hit);
      // Snapshot state for uniform-scale drag
      dragStartPts.current = [...drawPts];
      dragStartCanvasPos.current = canvasPos;
      return;
    }
    setDrawPts(prev => [...prev, canvasPos]);
  }, [findHitPoint, screenToCanvas, viewTransform, drawPts]);

  const handleCanvasMove = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    const screen = getScreenPos(e);

    // Pinch zoom
    if ("touches" in e && e.touches.length === 2) {
      const t0 = e.touches[0], t1 = e.touches[1];
      const d = Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY);
      if (lastPinchDist.current !== null) {
        const scale = d / lastPinchDist.current;
        const mx = (t0.clientX + t1.clientX) / 2;
        const my = (t0.clientY + t1.clientY) / 2;
        const canvas = drawCanvasRef.current!;
        const rect = canvas.getBoundingClientRect();
        const cx = mx - rect.left, cy = my - rect.top;
        setViewTransform(prev => {
          const newZoom = Math.min(Math.max(prev.zoom * scale, 0.25), 10);
          const newPanX = cx - (cx - prev.panX) * (newZoom / prev.zoom);
          const newPanY = cy - (cy - prev.panY) * (newZoom / prev.zoom);
          return { zoom: newZoom, panX: newPanX, panY: newPanY };
        });
      }
      lastPinchDist.current = d;
      return;
    }

    // Pan drag
    if (isPanning && panStart) {
      const dx = screen.x - panStart.x;
      const dy = screen.y - panStart.y;
      setViewTransform({ ...panOrigin, panX: panOrigin.panX + dx, panY: panOrigin.panY + dy });
      return;
    }

    const canvasPos = screenToCanvas(screen.x, screen.y);
    if (draggingIdx !== null) {
      if (uniformScale && dragStartPts.current.length >= 3) {
        // Uniform-scale from centroid: compute scale based on how far the dragged
        // point has moved from the centroid compared to its start distance
        const startPts = dragStartPts.current;
        const c = centroid(startPts);
        const startDragPt = startPts[draggingIdx];
        const startDist = dist(c, startDragPt);
        const currDist = dist(c, canvasPos);
        if (startDist > 0.5) {
          const scale = currDist / startDist;
          setDrawPts(startPts.map(p => ({
            x: c.x + (p.x - c.x) * scale,
            y: c.y + (p.y - c.y) * scale,
          })));
        }
      } else {
        setDrawPts(prev => prev.map((p, i) => i === draggingIdx ? canvasPos : p));
      }
    } else {
      const hit = findHitPoint(canvasPos);
      setHoverIdx(hit !== -1 ? hit : null);
    }
  }, [draggingIdx, findHitPoint, isPanning, panStart, panOrigin, screenToCanvas, uniformScale]);

  const handleCanvasUp = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    if ("touches" in e && e.touches.length < 2) lastPinchDist.current = null;
    setDraggingIdx(null);
    setIsPanning(false);
    setPanStart(null);
  }, []);
  const handleCanvasLeave = useCallback(() => { setDraggingIdx(null); setHoverIdx(null); setIsPanning(false); setPanStart(null); }, []);

  // Fit all points into view with padding
  const fitToView = useCallback((pts: Pt[]) => {
    const canvas = drawCanvasRef.current;
    if (!canvas) return;
    const cw = canvas.width, ch = canvas.height;
    if (pts.length === 0) { setViewTransform({ zoom: 1, panX: 0, panY: 0 }); return; }
    const xs = pts.map(p => p.x), ys = pts.map(p => p.y);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);
    const pad = 80;
    const scaleX = (cw - pad * 2) / (maxX - minX || 1);
    const scaleY = (ch - pad * 2) / (maxY - minY || 1);
    const zoom = Math.min(Math.max(Math.min(scaleX, scaleY), 0.25), 8);
    const panX = cw / 2 - ((minX + maxX) / 2) * zoom;
    const panY = ch / 2 - ((minY + maxY) / 2) * zoom;
    setViewTransform({ zoom, panX, panY });
  }, []);

  // Zoom helpers — zoom toward shape centroid if points exist, else canvas center
  const zoomStep = useCallback((factor: number) => {
    const canvas = drawCanvasRef.current;
    if (!canvas) return;
    setViewTransform(prev => {
      const newZoom = Math.min(Math.max(prev.zoom * factor, 0.25), 10);
      // Zoom toward canvas center always (predictable behavior for button press)
      const cx = canvas.width / 2, cy = canvas.height / 2;
      const newPanX = cx - (cx - prev.panX) * (newZoom / prev.zoom);
      const newPanY = cy - (cy - prev.panY) * (newZoom / prev.zoom);
      return { zoom: newZoom, panX: newPanX, panY: newPanY };
    });
  }, []);

  const resetView = useCallback(() => {
    fitToView(drawPts);
  }, [drawPts, fitToView]);

  const removeLastPoint = () => setDrawPts(prev => prev.slice(0, -1));
  const clearDraw = () => { setDrawPts([]); setViewTransform({ zoom: 1, panX: 0, panY: 0 }); };

  // Load a template shape centered on the canvas
  const loadTemplate = useCallback((tpl: ShapeTemplate) => {
    const canvas = drawCanvasRef.current;
    const cw = canvas ? canvas.width : 800;
    const ch = canvas ? canvas.height : 460;
    const r = Math.min(cw, ch) * 0.32; // comfortable starting radius
    const pts = tpl.pts(cw / 2, ch / 2, r);
    setDrawPts(pts);
    setViewTransform({ zoom: 1, panX: 0, panY: 0 }); // reset view so shape is centered
    setTemplateOpen(false);
    toast({ title: `${tpl.label} loaded` });
  }, [toast]);

  const handleSaveShape = () => {
    if (drawPts.length < 3) { toast({title:"Need at least 3 points",variant:"destructive"}); return; }
    const name = saveName.trim() || shapeName(drawPts.length);
    const pid = saveProjectId ?? (activeProjectId !== "all" ? activeProjectId : null);
    saveMutation.mutate({ name, vertices: JSON.stringify(drawPts), projectId: pid });
  };

  const loadToCanvas = (shape: SavedShape) => {
    try {
      const verts: Pt[] = JSON.parse(shape.vertices);
      const canvas = drawCanvasRef.current;
      if (canvas && verts.length > 0) {
        const xs=verts.map(p=>p.x),ys=verts.map(p=>p.y);
        const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);
        const offX=(canvas.width-(maxX-minX))/2-minX;
        const offY=(canvas.height-(maxY-minY))/2-minY;
        setDrawPts(verts.map(p=>({x:p.x+offX,y:p.y+offY})));
      } else {
        setDrawPts(verts);
      }
      setMainTab("draw");
      setViewTransform({ zoom: 1, panX: 0, panY: 0 });
      toast({ title: `"${shape.name}" loaded to canvas` });
    } catch { toast({ title: "Failed to load shape", variant: "destructive" }); }
  };

  const downloadDraw = () => {
    const canvas = drawCanvasRef.current;
    if (!canvas || drawPts.length < 2) return;
    const a = document.createElement("a");
    a.download = "shape-draw.png";
    a.href = canvas.toDataURL();
    a.click();
  };

  const drawAngles = computeAngles(drawPts);
  const drawAngleSum = Math.round(drawAngles.reduce((a,b)=>a+b,0));

  const drawShapeName = (() => {
    if (drawPts.length < 3) return "";
    if (drawPts.length === 3) return triType(drawAngles, drawPts);
    if (drawPts.length === 4) return quadType(drawAngles, drawPts);
    return shapeName(drawPts.length);
  })();

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">

      {/* Header */}
      <header className="border-b border-border px-4 py-3 flex items-center justify-between sticky top-0 z-10 bg-background/95 backdrop-blur">
        <div className="flex items-center gap-3">
          <svg width="32" height="32" viewBox="0 0 32 32" fill="none" aria-label="ShapeScan logo">
            <rect x="2" y="2" width="28" height="28" rx="7" fill="hsl(var(--primary))"/>
            <polygon points="16,6 28,26 4,26" fill="none" stroke="white" strokeWidth="2" strokeLinejoin="round"/>
            <circle cx="16" cy="6" r="2" fill="white"/>
            <circle cx="28" cy="26" r="2" fill="white"/>
            <circle cx="4" cy="26" r="2" fill="white"/>
          </svg>
          <div>
            <h1 className="text-sm font-bold leading-none">ShapeScan</h1>
            <p className="text-xs text-muted-foreground leading-none mt-0.5">Angle Detector</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-xs gap-1 hidden sm:flex">
            <BookMarked className="w-3 h-3"/>{allShapes.length} saved
          </Badge>
          <div className="hidden sm:flex items-center gap-1 px-2 py-1 rounded-lg bg-muted text-xs text-muted-foreground">
            <User className="w-3 h-3" />
            <span>{user.username}</span>
          </div>
          <button
            data-testid="button-theme-toggle"
            onClick={() => setDark(!dark)}
            className="p-2 rounded-lg hover:bg-muted transition-colors"
            aria-label="Toggle theme"
          >
            {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          <button
            data-testid="button-logout"
            onClick={onLogout}
            className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-red-400"
            aria-label="Sign out"
            title="Sign out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      <main className="flex-1 container max-w-5xl mx-auto px-4 py-4 flex flex-col gap-4">
        <Tabs value={mainTab} onValueChange={v => setMainTab(v as any)}>
          <TabsList className="w-full grid grid-cols-3 mb-2">
            <TabsTrigger value="scan" data-testid="tab-scan" className="gap-1.5">
              <ScanLine className="w-3.5 h-3.5"/>Scan
            </TabsTrigger>
            <TabsTrigger value="draw" data-testid="tab-draw" className="gap-1.5">
              <MousePointer2 className="w-3.5 h-3.5"/>Draw
            </TabsTrigger>
            <TabsTrigger value="library" data-testid="tab-library" className="gap-1.5">
              <BookMarked className="w-3.5 h-3.5"/>Library
              {allShapes.length > 0 && (
                <span className="ml-1 bg-primary/15 text-primary rounded-full px-1.5 text-xs font-bold">{allShapes.length}</span>
              )}
            </TabsTrigger>
          </TabsList>

          {/* ══════════════════ SCAN TAB ══════════════════ */}
          <TabsContent value="scan" className="mt-0">
            {!imageSrc && !scanning && (
              <div className="fade-in">
                <Tabs value={scanTab} onValueChange={v=>{setScanTab(v as any); stopCamera();}}>
                  <TabsList className="mb-3">
                    <TabsTrigger value="upload"><Upload className="w-4 h-4 mr-2"/>Upload</TabsTrigger>
                    <TabsTrigger value="camera"><Camera className="w-4 h-4 mr-2"/>Camera</TabsTrigger>
                  </TabsList>
                  <TabsContent value="upload">
                    <div
                      data-testid="drop-zone"
                      className={`scanner-grid border-2 border-dashed border-border rounded-xl p-10 text-center cursor-pointer transition-all ${draggingZone?"drop-zone-active":"hover:border-primary/50 hover:bg-primary/5"}`}
                      onDragOver={e=>{e.preventDefault();setDraggingZone(true);}}
                      onDragLeave={()=>setDraggingZone(false)}
                      onDrop={e=>{e.preventDefault();setDraggingZone(false);const f=e.dataTransfer.files[0];if(f)handleFile(f);}}
                      onClick={()=>fileInputRef.current?.click()}
                    >
                      <input ref={fileInputRef} type="file" accept="image/*" className="hidden" data-testid="input-file"
                        onChange={e=>{const f=e.target.files?.[0];if(f)handleFile(f);}}/>
                      <div className="flex flex-col items-center gap-3">
                        <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
                          <Upload className="w-7 h-7 text-primary"/>
                        </div>
                        <div>
                          <p className="font-semibold">Drop an image here</p>
                          <p className="text-sm text-muted-foreground mt-0.5">or click to browse — PNG, JPG, WebP</p>
                        </div>
                        <div className="flex gap-2 flex-wrap justify-center">
                          {["Triangles","Quadrilaterals","Pentagons","Polygons"].map(t=>(
                            <Badge key={t} variant="secondary" className="text-xs">{t}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="camera">
                    <div className="rounded-xl border border-border overflow-hidden bg-black aspect-video relative flex items-center justify-center">
                      {cameraActive ? (
                        <>
                          <video ref={videoRef} className="w-full h-full object-cover" playsInline muted/>
                          <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-3">
                            <Button data-testid="button-capture" onClick={captureCamera}><Camera className="w-4 h-4 mr-2"/>Capture</Button>
                            <Button variant="outline" onClick={stopCamera}>Cancel</Button>
                          </div>
                        </>
                      ) : (
                        <div className="flex flex-col items-center gap-4 text-white/70 p-8">
                          <Camera className="w-12 h-12"/>
                          <Button data-testid="button-start-camera" onClick={startCamera}><Camera className="w-4 h-4 mr-2"/>Start Camera</Button>
                        </div>
                      )}
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            )}

            {scanning && (
              <div className="fade-in flex flex-col items-center gap-5 py-14">
                <div className="relative w-20 h-20">
                  <div className="absolute inset-0 rounded-full border-2 border-primary/30"/>
                  <div className="absolute inset-0 rounded-full border-t-2 border-primary animate-spin"/>
                  <ScanLine className="absolute inset-0 m-auto w-9 h-9 text-primary"/>
                </div>
                <div className="text-center">
                  <p className="font-semibold">Scanning for shapes…</p>
                  <p className="text-sm text-muted-foreground mt-1">Detecting edges and computing angles</p>
                </div>
              </div>
            )}

            {imageSrc && !scanning && (
              <div className="fade-in flex flex-col gap-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="secondary" className="gap-1.5">
                      <ScanLine className="w-3.5 h-3.5"/>{shapes.length} shape{shapes.length!==1?"s":""} found
                    </Badge>
                    {selectedShape&&<Badge style={{backgroundColor:selectedShape.color+"22",color:selectedShape.color,borderColor:selectedShape.color+"44"}} variant="outline">{selectedShape.name}</Badge>}
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" data-testid="button-download" onClick={downloadScan}><Download className="w-3.5 h-3.5 mr-1.5"/>Save</Button>
                    <Button size="sm" variant="outline" data-testid="button-reset" onClick={resetScan}><RefreshCw className="w-3.5 h-3.5 mr-1.5"/>New</Button>
                  </div>
                </div>

                {/* Image + transparent overlay canvas on top */}
                <div className="rounded-xl overflow-hidden border border-border bg-black flex justify-center">
                  <div style={{position:"relative",display:"inline-block"}}>
                    <img ref={imgRef} src={imageSrc} alt="Scanned"
                      className="block max-w-full max-h-[480px] object-contain"
                      style={{display:"block"}}
                    />
                    {/* Transparent overlay canvas — sits directly on top of the photo */}
                    <canvas
                      ref={overlayRef}
                      data-testid="canvas-overlay"
                      className="absolute inset-0 cursor-pointer"
                      style={{top:0,left:0,position:"absolute"}}
                      onClick={e=>{
                        if (!overlayRef.current||!imgRef.current) return;
                        const rect=overlayRef.current.getBoundingClientRect();
                        const mx=e.clientX-rect.left, my=e.clientY-rect.top;
                        const hit=shapes.find(s=>{
                          const cx=s.centroid.x*displayScale, cy=s.centroid.y*displayScale;
                          return Math.sqrt((mx-cx)**2+(my-cy)**2)<Math.sqrt(s.area*displayScale*displayScale)*0.5+30;
                        });
                        setSelectedShape(hit===selectedShape?null:hit??null);
                      }}
                    />
                  </div>
                </div>

                {shapes.length>0&&(
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {shapes.map(shape=>(
                      <Card key={shape.id} data-testid={`card-shape-${shape.id}`}
                        className={`cursor-pointer transition-all hover:shadow-md ${selectedShape?.id===shape.id?"ring-2":"ring-0"}`}
                        style={selectedShape?.id===shape.id?{borderColor:shape.color}:{}}
                        onClick={()=>setSelectedShape(selectedShape?.id===shape.id?null:shape)}
                      >
                        <CardContent className="p-3">
                          <div className="flex items-center gap-2 mb-2">
                            <div className="w-6 h-6 rounded-md flex items-center justify-center" style={{backgroundColor:shape.color+"22",color:shape.color}}>
                              <ShapeIcon sides={shape.sides}/>
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-sm truncate">{shape.name}</p>
                              <p className="text-xs text-muted-foreground">{shape.sides} sides · Σ{Math.round(shape.angles.reduce((a,b)=>a+b,0))}°</p>
                            </div>
                            <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{backgroundColor:shape.color}}/>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {shape.angles.map((a,i)=>(
                              <span key={i} className="angle-badge px-1.5 py-0.5 rounded text-white text-xs" style={{backgroundColor:shape.color}}>
                                ∠{i+1} {a}°
                              </span>
                            ))}
                          </div>
                          <div className="mt-2 pt-2 border-t border-border grid grid-cols-2 gap-1 text-xs text-muted-foreground">
                            <div className="flex items-center gap-1"><ZoomIn className="w-3 h-3"/>{shape.area.toLocaleString()} px²</div>
                            <div className="flex items-center gap-1"><Ruler className="w-3 h-3"/>{shape.perimeter} px</div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            )}
          </TabsContent>

          {/* ══════════════════ DRAW TAB ══════════════════ */}
          <TabsContent value="draw" className="mt-0">
            <div className="flex flex-col gap-3">

              {/* Top toolbar */}
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2 flex-wrap">
                  {drawPts.length >= 3 ? (
                    <>
                      <Badge variant="secondary" className="gap-1 font-mono">{drawShapeName}</Badge>
                      <Badge variant="outline" className="font-mono">Σ {drawAngleSum}°</Badge>
                      <Badge variant="outline" className="font-mono">{drawPts.length} pts</Badge>
                    </>
                  ) : (
                    <span className="text-sm text-muted-foreground flex items-center gap-1.5">
                      <CornerDownRight className="w-3.5 h-3.5"/>
                      {drawPts.length === 0
                        ? "Click the canvas to place points"
                        : `${3 - drawPts.length} more point${3-drawPts.length!==1?"s":""} to form a shape`}
                    </span>
                  )}
                </div>
                <div className="flex gap-1.5 flex-wrap">
                  {/* Shape template picker button */}
                  <Button size="sm" variant="outline" onClick={() => setTemplateOpen(v => !v)} data-testid="button-templates">
                    <Square className="w-3.5 h-3.5 mr-1.5"/>Templates
                  </Button>
                  {drawPts.length > 0 && (
                    <>
                      <Button size="sm" variant="outline" onClick={removeLastPoint} data-testid="button-undo">
                        <X className="w-3.5 h-3.5 mr-1"/>Undo
                      </Button>
                      <Button size="sm" variant="outline" onClick={clearDraw} data-testid="button-clear">
                        <RefreshCw className="w-3.5 h-3.5 mr-1"/>Clear
                      </Button>
                      <Button size="sm" variant="outline" onClick={downloadDraw} data-testid="button-draw-download">
                        <Download className="w-3.5 h-3.5 mr-1"/>Save img
                      </Button>
                    </>
                  )}
                  {drawPts.length >= 3 && (
                    <Button size="sm" data-testid="button-save-library" onClick={() => { setSaveProjectId(typeof activeProjectId === "number" ? activeProjectId : null); setSaveDialogOpen(true); }}>
                      <BookMarked className="w-3.5 h-3.5 mr-1.5"/>Save to Library
                    </Button>
                  )}
                </div>
              </div>

              {/* Shape template picker panel */}
              {templateOpen && (
                <div className="bg-card border border-border rounded-xl p-3 fade-in">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Shape Templates</p>
                    <button onClick={() => setTemplateOpen(false)} className="text-muted-foreground hover:text-foreground transition-colors p-0.5 rounded">
                      <X className="w-3.5 h-3.5"/>
                    </button>
                  </div>
                  <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-7 gap-1.5">
                    {SHAPE_TEMPLATES.map(tpl => (
                      <button
                        key={tpl.id}
                        onClick={() => loadTemplate(tpl)}
                        title={tpl.label}
                        className="flex flex-col items-center gap-1 p-2 rounded-lg border border-border bg-muted/40 hover:bg-primary/10 hover:border-primary/40 transition-all group"
                      >
                        <span className="text-xl leading-none group-hover:scale-110 transition-transform">{tpl.icon}</span>
                        <span className="text-[9px] text-muted-foreground text-center leading-tight line-clamp-2">{tpl.label}</span>
                      </button>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 pt-2 border-t border-border">
                    Load a template, then drag any point — enable <strong>Scale mode</strong> in the toolbar to resize evenly from center.
                  </p>
                </div>
              )}

              {/* Background image toolbar */}
              <div className="flex items-center gap-3 flex-wrap bg-muted/50 rounded-lg px-3 py-2 border border-border">
                <input
                  ref={bgFileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  data-testid="input-bg-image"
                  onChange={e => { const f = e.target.files?.[0]; if (f) handleBgFile(f); }}
                />
                <Button
                  size="sm"
                  variant={bgImage ? "default" : "outline"}
                  className="shrink-0"
                  data-testid="button-load-bg"
                  onClick={() => bgFileRef.current?.click()}
                >
                  <ImageIcon className="w-3.5 h-3.5 mr-1.5"/>
                  {bgImage ? "Change photo" : "Load photo background"}
                </Button>

                {bgImage && (
                  <>
                    <div className="flex items-center gap-2 flex-1 min-w-[160px]">
                      <EyeOff className="w-3.5 h-3.5 text-muted-foreground shrink-0"/>
                      <Slider
                        data-testid="slider-opacity"
                        min={0}
                        max={1}
                        step={0.05}
                        value={[bgOpacity]}
                        onValueChange={([v]) => setBgOpacity(v)}
                        className="flex-1"
                      />
                      <span className="text-xs text-muted-foreground w-8 text-right">{Math.round(bgOpacity*100)}%</span>
                    </div>
                    <span className="text-xs text-muted-foreground truncate max-w-[140px] hidden sm:block">{bgLabel}</span>
                    <Button size="sm" variant="ghost" className="px-2 text-muted-foreground" data-testid="button-clear-bg" onClick={clearBg}>
                      <X className="w-3.5 h-3.5"/>
                    </Button>
                  </>
                )}

                {!bgImage && (
                  <span className="text-xs text-muted-foreground">Overlay a photo and trace shapes on top</span>
                )}
              </div>

              {/* Zoom + mode toolbar */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <div className="flex items-center gap-0.5 rounded-lg border border-border bg-card p-0.5">
                  <button
                    onClick={() => zoomStep(1.3)}
                    className="px-2.5 py-1.5 text-xs font-mono hover:bg-muted rounded-md transition-colors"
                    title="Zoom in"
                  >+</button>
                  <span className="px-2 text-xs font-mono text-muted-foreground min-w-[3.5rem] text-center tabular-nums">
                    {Math.round(viewTransform.zoom * 100)}%
                  </span>
                  <button
                    onClick={() => zoomStep(1 / 1.3)}
                    className="px-2.5 py-1.5 text-xs font-mono hover:bg-muted rounded-md transition-colors"
                    title="Zoom out"
                  >−</button>
                </div>
                <button
                  onClick={resetView}
                  className="px-2.5 py-1.5 text-xs rounded-lg border border-border bg-card hover:bg-muted transition-colors font-medium"
                  title="Fit shape to view"
                >Fit</button>
                {/* Uniform scale toggle */}
                <button
                  onClick={() => setUniformScale(v => !v)}
                  title="Scale mode: drag any point to resize the entire shape proportionally from its center"
                  className={`px-2.5 py-1.5 text-xs rounded-lg border transition-all font-medium flex items-center gap-1.5 ${
                    uniformScale
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-card border-border hover:bg-muted text-muted-foreground"
                  }`}
                >
                  <ZoomIn className="w-3 h-3"/>
                  Scale mode {uniformScale ? "ON" : "OFF"}
                </button>
                {/* Tabs toggle */}
                <button
                  onClick={() => setShowTabs(v => !v)}
                  title="Toggle seam allowance tabs on every edge"
                  className={`px-2.5 py-1.5 text-xs rounded-lg border transition-all font-medium flex items-center gap-1.5 ${
                    showTabs
                      ? "bg-amber-500 text-white border-amber-500"
                      : "bg-card border-border hover:bg-muted text-muted-foreground"
                  }`}
                >
                  <svg className="w-3 h-3" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <rect x="1" y="3" width="10" height="6" rx="0.5"/>
                    <rect x="3" y="1" width="6" height="2" rx="0.5"/>
                  </svg>
                  Tabs {showTabs ? "ON" : "OFF"}
                </button>
                <span className="text-xs text-muted-foreground hidden sm:block">
                  {isPanning ? "Panning…" : uniformScale ? "Drag any point to scale from center" : "Scroll to zoom · Space+drag to pan"}
                </span>
              </div>

              {/* Tab size slider — only when tabs are active */}
              {showTabs && (
                <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg border border-amber-400/40 bg-amber-50/60 dark:bg-amber-900/20">
                  <svg className="w-3.5 h-3.5 text-amber-600 shrink-0" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <rect x="1" y="3" width="10" height="6" rx="0.5"/>
                    <rect x="3" y="1" width="6" height="2" rx="0.5"/>
                  </svg>
                  <span className="text-xs font-medium text-amber-700 dark:text-amber-400 shrink-0">Tab depth</span>
                  {globalPxPerUnit && unitMode !== "px" ? (
                    // Real-unit mode: slider in real units, label shows real measurement
                    <>
                      <Slider
                        min={1}
                        max={unitMode === "imperial" ? 240 : 6000}
                        step={unitMode === "imperial" ? 1 : 1}
                        value={[Math.round(tabSize / globalPxPerUnit * (unitMode === "imperial" ? 1 : 1))]}
                        onValueChange={([v]) => setTabSize(Math.round(v * globalPxPerUnit))}
                        className="flex-1 min-w-[120px]"
                      />
                      <span className="text-xs font-mono text-amber-700 dark:text-amber-400 w-20 text-right shrink-0">
                        {fmtDist(tabSize, unitMode, globalPxPerUnit)}
                      </span>
                    </>
                  ) : (
                    // Pixel mode
                    <>
                      <Slider
                        min={5}
                        max={200}
                        step={1}
                        value={[tabSize]}
                        onValueChange={([v]) => setTabSize(v)}
                        className="flex-1 min-w-[120px]"
                      />
                      <span className="text-xs font-mono text-amber-700 dark:text-amber-400 w-12 text-right shrink-0">{tabSize} px</span>
                    </>
                  )}
                  {/* Bake tabs button */}
                  {drawPts.length >= 3 && (
                    <button
                      onClick={() => {
                        const baked = bakeTabsIntoShape(drawPts, tabSize);
                        setDrawPts(baked);
                        setShowTabs(false);
                        setEdgeValues([]);
                        globalScaleRef.current = null;
                      }}
                      title="Merge tabs into the shape outline permanently"
                      className="ml-auto px-2.5 py-1.5 text-xs rounded-lg border border-amber-500 text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/30 hover:bg-amber-100 dark:hover:bg-amber-900/50 font-medium flex items-center gap-1.5 shrink-0 transition-colors"
                    >
                      <svg className="w-3 h-3" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.5">
                        <path d="M2 10 L6 2 L10 10 Z"/>
                        <line x1="6" y1="7" x2="6" y2="10"/>
                      </svg>
                      Bake into shape
                    </button>
                  )}
                </div>
              )}

              {/* Scale / real-world measurement panel */}
              <div className="flex flex-wrap items-center gap-2.5 px-3 py-2 rounded-lg border border-border bg-card">
                {/* Unit mode selector */}
                <svg className="w-3.5 h-3.5 text-muted-foreground shrink-0" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M2 12 L5 2 L7 8 L9 2 L12 12"/>
                  <line x1="3.5" y1="9" x2="10.5" y2="9"/>
                </svg>
                <span className="text-xs font-medium text-muted-foreground shrink-0">Scale</span>
                <div className="flex rounded-md border border-border overflow-hidden shrink-0">
                  {(["px", "imperial", "metric"] as UnitMode[]).map(m => (
                    <button
                      key={m}
                      onClick={() => { setUnitMode(m); setEdgeValues([]); globalScaleRef.current = null; }}
                      className={`px-2.5 py-1 text-xs font-medium transition-colors ${
                        unitMode === m
                          ? "bg-primary text-primary-foreground"
                          : "bg-transparent text-muted-foreground hover:bg-muted"
                      }`}
                    >
                      {m === "px" ? "px" : m === "imperial" ? "ft / in" : "metric"}
                    </button>
                  ))}
                </div>

                {unitMode !== "px" && drawPts.length >= 2 && (
                  <div className="w-full flex flex-col gap-1.5 pt-1">
                    <span className="text-xs text-muted-foreground">
                      {globalPxPerUnit
                        ? "Type a new length to resize the shape. All units share one scale."
                        : "Set s1 to calibrate the scale — then all edges + tabs use that ratio."}
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {Array.from({ length: edgeCount }, (_, i) => {
                        const a = drawPts[i], b = drawPts[(i + 1) % drawPts.length];
                        const val = edgeValues[i] ?? "";
                        const parsedVal = parseRealValue(val, unitMode);
                        const hasValidVal = parsedVal !== null && parsedVal > 0;
                        const isInvalid = val !== "" && !hasValidVal;
                        // Show current real-world length from global scale if no typed value
                        const currentRealLabel = globalPxPerUnit && !val
                          ? fmtDist(dist(a, b), unitMode, globalPxPerUnit)
                          : "";
                        return (
                          <div key={i} className="flex items-center gap-1">
                            <span className="text-xs font-mono text-muted-foreground shrink-0">s{i+1}</span>
                            <input
                              type="text"
                              value={val}
                              onChange={e => {
                                const next = [...edgeValues];
                                next[i] = e.target.value;
                                setEdgeValues(next);
                              }}
                              onBlur={() => {
                                const realUnits = parseRealValue(edgeValues[i] ?? "", unitMode);
                                if (!realUnits || realUnits <= 0 || drawPts.length < 2) return;
                                const a = drawPts[i], b = drawPts[(i + 1) % drawPts.length];
                                const currentPx = dist(a, b);
                                if (globalScaleRef.current === null) {
                                  // First ever value — calibrate scale, no resize needed
                                  globalScaleRef.current = currentPx / realUnits;
                                  // Force re-render so globalPxPerUnit updates
                                  setEdgeValues(ev => [...ev]);
                                } else {
                                  // Scale already set — resize shape so this edge matches
                                  const targetPx = realUnits * globalScaleRef.current;
                                  if (Math.abs(targetPx - currentPx) > 0.5) {
                                    setDrawPts(stretchEdge(drawPts, i, targetPx));
                                  }
                                }
                              }}
                              onKeyDown={e => {
                                if (e.key === "Enter") (e.target as HTMLInputElement).blur();
                              }}
                              placeholder={globalPxPerUnit
                                ? fmtDist(dist(a, b), unitMode, globalPxPerUnit)
                                : unitMode === "imperial" ? "e.g. 18\"" : "e.g. 45cm"}
                              className={`text-xs rounded border px-2 py-0.5 w-24 bg-card text-foreground placeholder:text-muted-foreground/40 ${
                                isInvalid ? "border-red-400" : hasValidVal ? "border-emerald-500/60" : "border-border"
                              }`}
                            />
                            {hasValidVal && (
                              <span className="text-xs text-emerald-600 dark:text-emerald-400 font-mono shrink-0">✓</span>
                            )}
                            {currentRealLabel && (
                              <span className="text-xs text-muted-foreground/60 font-mono shrink-0">{currentRealLabel}</span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Canvas */}
              <div
                ref={drawContainerRef}
                className={`relative border-2 rounded-xl overflow-hidden select-none ${bgImage ? "border-primary/40" : "scanner-grid border-dashed border-border"}`}
                style={{
                  height: 460,
                  cursor: isPanning || panStart
                    ? "grabbing"
                    : spaceHeld.current
                    ? "grab"
                    : draggingIdx !== null
                    ? "grabbing"
                    : hoverIdx !== null
                    ? "grab"
                    : "crosshair",
                  background: bgImage ? "black" : undefined,
                }}
              >
                <canvas
                  ref={drawCanvasRef}
                  data-testid="canvas-draw"
                  style={{ touchAction: "none", width: "100%", height: "100%" }}
                  onMouseDown={handleCanvasDown}
                  onMouseMove={handleCanvasMove}
                  onMouseUp={handleCanvasUp}
                  onMouseLeave={handleCanvasLeave}
                  onTouchStart={handleCanvasDown}
                  onTouchMove={handleCanvasMove}
                  onTouchEnd={handleCanvasUp}
                  onWheel={handleCanvasWheel}
                />
              </div>

              {/* Live angle + side readout */}
              {drawPts.length >= 3 && (
                <div className="fade-in grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <Card>
                    <CardContent className="p-3">
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Interior Angles</p>
                      <div className="flex flex-wrap gap-1.5">
                        {drawAngles.map((a,i)=>(
                          <span key={i} data-testid={`draw-angle-${i}`}
                            className="angle-badge px-2 py-1 rounded text-white"
                            style={{ backgroundColor: DRAW_COLOR }}
                          >∠{i+1} {a}°</span>
                        ))}
                      </div>
                      <div className="mt-2 pt-2 border-t border-border flex gap-4 text-xs text-muted-foreground flex-wrap">
                        <span>Sum: <strong className="text-foreground">{drawAngleSum}°</strong></span>
                        <span>Expected: <strong className="text-foreground">{(drawPts.length-2)*180}°</strong></span>
                        <span>Area: <strong className="text-foreground">{fmtArea(polygonArea(drawPts), unitMode, avgPxPerUnit)}</strong></span>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-3">
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Side Lengths</p>
                      <div className="flex flex-wrap gap-1.5">
                        {drawPts.slice(0, edgeCount).map((_,i)=>{
                          const a=drawPts[i], b=drawPts[(i+1)%drawPts.length];
                          const ppu = edgePxPerUnit[i];
                          return (
                            <span key={i} className={`angle-badge px-2 py-1 rounded font-mono ${
                              ppu !== null
                                ? "bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 ring-1 ring-emerald-500/50"
                                : "bg-muted text-foreground"
                            }`}>
                              s{i+1} {fmtDist(dist(a,b), unitMode, ppu)}
                            </span>
                          );
                        })}
                      </div>
                      <div className="mt-2 pt-2 border-t border-border text-xs text-muted-foreground">
                        Perimeter: <strong className="text-foreground">{fmtDist(polygonPerimeter(drawPts), unitMode, avgPxPerUnit)}</strong>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {drawPts.length === 0 && (
                <p className="text-center text-sm text-muted-foreground py-2">
                  Click to add points · Drag to reshape · Scroll to zoom · Space+drag to pan
                </p>
              )}
            </div>
          </TabsContent>

          {/* ══════════════════ LIBRARY TAB ══════════════════ */}
          <TabsContent value="library" className="mt-0">
            <div className="flex gap-0 min-h-[500px]">

              {/* Project sidebar */}
              <div className="w-44 shrink-0 border-r border-border flex flex-col gap-0 pr-0">
                <div className="p-2 border-b border-border">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide px-1 mb-1.5">Projects</p>
                  {/* New project input */}
                  <form onSubmit={e => { e.preventDefault(); const n = newProjectName.trim(); if (n) createProjectMutation.mutate(n); }} className="flex gap-1">
                    <input
                      value={newProjectName}
                      onChange={e => setNewProjectName(e.target.value)}
                      placeholder="New project…"
                      className="flex-1 min-w-0 text-xs rounded border border-border bg-card px-2 py-1 text-foreground placeholder:text-muted-foreground/50"
                    />
                    <button type="submit" className="shrink-0 p-1 rounded border border-border bg-card hover:bg-muted text-muted-foreground" title="Create project">
                      <FolderPlus className="w-3.5 h-3.5"/>
                    </button>
                  </form>
                </div>

                {/* Sidebar items */}
                <div className="flex flex-col py-1 overflow-y-auto flex-1">
                  {/* All shapes */}
                  <button
                    onClick={() => setActiveProjectId("all")}
                    className={`flex items-center gap-2 px-3 py-1.5 text-xs text-left transition-colors ${
                      activeProjectId === "all"
                        ? "bg-primary/10 text-primary font-semibold"
                        : "text-muted-foreground hover:bg-muted"
                    }`}
                  >
                    <BookMarked className="w-3 h-3 shrink-0"/>
                    <span className="flex-1 truncate">All shapes</span>
                    {allShapes.length > 0 && <span className="text-xs opacity-60">{allShapes.length}</span>}
                  </button>

                  {/* Unassigned */}
                  <button
                    onClick={() => setActiveProjectId(null)}
                    className={`flex items-center gap-2 px-3 py-1.5 text-xs text-left transition-colors ${
                      activeProjectId === null
                        ? "bg-primary/10 text-primary font-semibold"
                        : "text-muted-foreground hover:bg-muted"
                    }`}
                  >
                    <Folder className="w-3 h-3 shrink-0"/>
                    <span className="flex-1 truncate">Unassigned</span>
                  </button>

                  {/* Project list */}
                  {projects.map(proj => (
                    <div key={proj.id} className="group relative">
                      {editingProjectId === proj.id ? (
                        <form
                          onSubmit={e => { e.preventDefault(); renameProjectMutation.mutate({ id: proj.id, name: editingProjectName }); }}
                          className="flex items-center gap-1 px-2 py-1"
                        >
                          <input
                            value={editingProjectName}
                            onChange={e => setEditingProjectName(e.target.value)}
                            className="flex-1 min-w-0 text-xs rounded border border-primary bg-card px-1.5 py-0.5 text-foreground"
                            autoFocus
                            onKeyDown={e => { if (e.key === "Escape") setEditingProjectId(null); }}
                          />
                          <button type="submit" className="text-primary"><Check className="w-3 h-3"/></button>
                        </form>
                      ) : (
                        <button
                          onClick={() => setActiveProjectId(proj.id)}
                          className={`w-full flex items-center gap-2 px-3 py-1.5 text-xs text-left transition-colors ${
                            activeProjectId === proj.id
                              ? "bg-primary/10 text-primary font-semibold"
                              : "text-muted-foreground hover:bg-muted"
                          }`}
                        >
                          <FolderOpen className="w-3 h-3 shrink-0"/>
                          <span className="flex-1 truncate">{proj.name}</span>
                        </button>
                      )}
                      {/* Rename / delete on hover */}
                      {editingProjectId !== proj.id && (
                        <div className="absolute right-1 top-1/2 -translate-y-1/2 hidden group-hover:flex gap-0.5">
                          <button
                            onClick={() => { setEditingProjectId(proj.id); setEditingProjectName(proj.name); }}
                            className="p-0.5 rounded hover:bg-muted text-muted-foreground"
                          ><Pencil className="w-2.5 h-2.5"/></button>
                          <button
                            onClick={() => { if (confirm(`Delete project "${proj.name}"? Shapes will be unassigned.`)) deleteProjectMutation.mutate(proj.id); }}
                            className="p-0.5 rounded hover:bg-destructive/10 text-destructive"
                          ><Trash2 className="w-2.5 h-2.5"/></button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Shape grid */}
              <div className="flex-1 min-w-0 p-3">
                {library.length === 0 ? (
                  <div className="flex flex-col items-center gap-4 py-16 text-muted-foreground">
                    <BookMarked className="w-12 h-12 opacity-20"/>
                    <div className="text-center">
                      <p className="font-medium">No shapes here yet</p>
                      <p className="text-sm mt-1">Draw a shape and save it to this project</p>
                    </div>
                    <Button onClick={() => setMainTab("draw")}><MousePointer2 className="w-4 h-4 mr-2"/>Go to Draw</Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
                    {library.map(shape => {
                      const verts: Pt[] = (() => { try { return JSON.parse(shape.vertices); } catch { return []; } })();
                      const angles = computeAngles(verts);
                      const angleSum = Math.round(angles.reduce((a,b)=>a+b,0));
                      const isEditing = editingId === shape.id;
                      return (
                        <Card key={shape.id} data-testid={`library-card-${shape.id}`} className="overflow-hidden">
                          <CardContent className="p-3">
                            <div className="flex items-start gap-3">
                              <LibraryThumbnail vertices={verts}/>
                              <div className="flex-1 min-w-0">
                                {isEditing ? (
                                  <div className="flex gap-1 mb-1">
                                    <Input value={editingName} onChange={e=>setEditingName(e.target.value)}
                                      className="h-7 text-sm" data-testid={`input-rename-${shape.id}`}
                                      onKeyDown={e=>{if(e.key==="Enter")renameMutation.mutate({id:shape.id,name:editingName});if(e.key==="Escape")setEditingId(null);}}
                                      autoFocus
                                    />
                                    <Button size="icon" className="h-7 w-7" onClick={()=>renameMutation.mutate({id:shape.id,name:editingName})}>
                                      <Check className="w-3.5 h-3.5"/>
                                    </Button>
                                  </div>
                                ) : (
                                  <p className="font-semibold text-sm truncate mb-0.5">{shape.name}</p>
                                )}
                                <p className="text-xs text-muted-foreground">{verts.length} vertices · Σ{angleSum}°</p>
                                <div className="flex flex-wrap gap-1 mt-1.5">
                                  {angles.slice(0,4).map((a,i)=>(
                                    <span key={i} className="angle-badge px-1.5 py-0.5 rounded text-white text-xs" style={{backgroundColor:DRAW_COLOR}}>
                                      ∠{i+1} {a}°
                                    </span>
                                  ))}
                                  {angles.length > 4 && <span className="text-xs text-muted-foreground">+{angles.length-4}</span>}
                                </div>
                                <p className="text-xs text-muted-foreground mt-1">{new Date(shape.createdAt).toLocaleDateString()}</p>
                              </div>
                            </div>
                            <div className="flex gap-1.5 mt-3 pt-3 border-t border-border">
                              <Button size="sm" variant="outline" className="flex-1 text-xs" data-testid={`button-load-${shape.id}`} onClick={()=>loadToCanvas(shape)}>
                                <CornerDownRight className="w-3 h-3 mr-1"/>Load
                              </Button>
                              <Button size="sm" variant="outline" className="px-2" data-testid={`button-rename-${shape.id}`}
                                onClick={()=>{ setEditingId(shape.id); setEditingName(shape.name); }}>
                                <Pencil className="w-3.5 h-3.5"/>
                              </Button>
                              {/* Move to project */}
                              <select
                                value={shape.projectId ?? ""}
                                onChange={e => moveShapeMutation.mutate({ id: shape.id, projectId: e.target.value === "" ? null : Number(e.target.value) })}
                                className="text-xs rounded border border-border bg-card px-1 py-1 text-muted-foreground max-w-[80px]"
                                title="Move to project"
                              >
                                <option value="">Unassigned</option>
                                {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                              </select>
                              <Button size="sm" variant="outline" className="px-2 text-destructive hover:bg-destructive/10" data-testid={`button-delete-${shape.id}`}
                                onClick={()=>deleteMutation.mutate(shape.id)}>
                                <Trash2 className="w-3.5 h-3.5"/>
                              </Button>
                            </div>
                            {/* Export row */}
                            <div className="flex gap-1.5 mt-1.5">
                              <Button
                                size="sm"
                                variant="outline"
                                className="flex-1 text-xs gap-1 text-emerald-600 border-emerald-600/40 hover:bg-emerald-600/10"
                                data-testid={`button-export-svg-${shape.id}`}
                                onClick={() => exportSVG(shape.name, verts)}
                                disabled={verts.length < 2}
                                title="Download as SVG vector file"
                              >
                                <Download className="w-3 h-3"/>SVG
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="flex-1 text-xs gap-1 text-blue-500 border-blue-500/40 hover:bg-blue-500/10"
                                data-testid={`button-export-dxf-${shape.id}`}
                                onClick={() => exportDXF(shape.name, verts)}
                                disabled={verts.length < 2}
                                title="Download as DXF (AutoCAD / CNC / laser cutter)"
                              >
                                <Download className="w-3 h-3"/>DXF
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Save dialog */}
      <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save shape to library</DialogTitle>
          </DialogHeader>
          <div className="py-2 space-y-3">
            <Input
              placeholder={`Name (default: ${shapeName(drawPts.length)})`}
              value={saveName}
              onChange={e=>setSaveName(e.target.value)}
              data-testid="input-save-name"
              onKeyDown={e=>{if(e.key==="Enter")handleSaveShape();}}
              autoFocus
            />
            {/* Project picker */}
            <div className="flex items-center gap-2">
              <FolderOpen className="w-4 h-4 text-muted-foreground shrink-0"/>
              <select
                value={saveProjectId ?? ""}
                onChange={e => setSaveProjectId(e.target.value === "" ? null : Number(e.target.value))}
                className="flex-1 text-sm rounded border border-border bg-card px-2 py-1.5 text-foreground"
              >
                <option value="">No project (Unassigned)</option>
                {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            {drawPts.length >= 3 && (
              <div className="text-sm text-muted-foreground space-y-1">
                <p>{drawPts.length} vertices · Σ{drawAngleSum}°</p>
                <p>Angles: {drawAngles.map((a,i)=>`∠${i+1} ${a}°`).join("  ")}</p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={()=>setSaveDialogOpen(false)}>Cancel</Button>
            <Button data-testid="button-confirm-save" onClick={handleSaveShape} disabled={saveMutation.isPending}>
              <BookMarked className="w-4 h-4 mr-2"/>Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <footer className="border-t border-border px-4 py-2.5 text-center text-xs text-muted-foreground">
        ShapeScan — Edge detection &amp; polygon analysis runs entirely in your browser
      </footer>
    </div>
  );
}
