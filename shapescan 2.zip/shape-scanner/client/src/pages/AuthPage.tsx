import { useState } from "react";
// Use raw fetch with credentials so auth cookies work across the proxy
const API_BASE = (window as any).__API_BASE__ ||
  (typeof "__PORT_5000__" === "string" && !"__PORT_5000__".startsWith("__")
    ? "__PORT_5000__"
    : "");
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { ScanLine, UserPlus, LogIn } from "lucide-react";

interface AuthPageProps {
  onAuth: (user: { id: number; username: string }) => void;
}

export default function AuthPage({ onAuth }: AuthPageProps) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!username.trim()) {
      toast({ title: "Enter a username", variant: "destructive" });
      return;
    }
    if (!/^\d{5,}$/.test(password)) {
      toast({
        title: "Invalid password",
        description: "Password must be at least 5 digits (numbers only — e.g. 12345)",
        variant: "destructive",
      });
      return;
    }
    setLoading(true);
    try {
      const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const res = await fetch(`${API_BASE}${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ username, password }),
      });
      const ct = res.headers.get("content-type") || "";
      if (!ct.includes("application/json")) {
        toast({ title: "Server unavailable. Please try again later.", variant: "destructive" });
        return;
      }
      const data = await res.json();
      if (!res.ok) {
        toast({ title: data.error || "Authentication failed", variant: "destructive" });
        return;
      }
      onAuth(data);
    } catch {
      toast({ title: "Network error. Please try again.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6">
      {/* Logo / branding */}
      <div className="flex items-center gap-3 mb-8">
        <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center shadow-lg">
          <ScanLine className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">ShapeScan</h1>
          <p className="text-xs text-muted-foreground">Angle Detector &amp; Shape Designer</p>
        </div>
      </div>

      {/* Card */}
      <div className="w-full max-w-sm bg-card border border-border rounded-2xl shadow-xl p-8">
        {/* Tab switcher */}
        <div className="flex rounded-lg overflow-hidden border border-border mb-6">
          <button
            type="button"
            onClick={() => setMode("login")}
            className={`flex-1 py-2 text-sm font-medium transition-colors ${
              mode === "login"
                ? "bg-indigo-600 text-white"
                : "bg-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => setMode("register")}
            className={`flex-1 py-2 text-sm font-medium transition-colors ${
              mode === "register"
                ? "bg-indigo-600 text-white"
                : "bg-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            Create Account
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5 uppercase tracking-wider">
              Username
            </label>
            <Input
              data-testid="input-username"
              placeholder="Enter your username"
              value={username}
              onChange={e => setUsername(e.target.value)}
              autoComplete="username"
              disabled={loading}
              className="bg-background"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5 uppercase tracking-wider">
              Password (numeric, 5+ digits)
            </label>
            <Input
              data-testid="input-password"
              type="password"
              placeholder="e.g. 12345"
              value={password}
              onChange={e => setPassword(e.target.value)}
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              inputMode="numeric"
              disabled={loading}
              className="bg-background"
            />
            <p className="text-xs text-muted-foreground mt-1.5">
              Must be at least 5 numbers (digits only — no letters)
            </p>
          </div>

          <Button
            data-testid="button-submit-auth"
            type="submit"
            disabled={loading}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white gap-2"
          >
            {mode === "login" ? (
              <><LogIn className="w-4 h-4" /> Sign In</>
            ) : (
              <><UserPlus className="w-4 h-4" /> Create Account</>
            )}
          </Button>
        </form>

        <p className="text-center text-xs text-muted-foreground mt-5">
          {mode === "login"
            ? "Don't have an account? "
            : "Already have an account? "}
          <button
            type="button"
            onClick={() => setMode(mode === "login" ? "register" : "login")}
            className="text-indigo-400 hover:text-indigo-300 underline underline-offset-2"
          >
            {mode === "login" ? "Create one" : "Sign in"}
          </button>
        </p>
      </div>

      <p className="text-xs text-muted-foreground mt-6 text-center max-w-xs">
        Your shapes and projects are private to your account.
      </p>
    </div>
  );
}
