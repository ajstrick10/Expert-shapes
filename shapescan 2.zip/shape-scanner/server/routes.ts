import type { Express, Request, Response, NextFunction } from "express";
import { type Server } from "http";
import session from "express-session";
import { storage } from "./storage";
import { insertSavedShapeSchema, insertProjectSchema } from "@shared/schema";
import { z } from "zod";

// Augment session type
declare module "express-session" {
  interface SessionData {
    userId: number;
    username: string;
  }
}

// ── Auth middleware ──────────────────────────────────────────────────────────
function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session?.userId) {
    return res.status(401).json({ error: "Not authenticated" });
  }
  next();
}

export async function registerRoutes(_httpServer: Server, app: Express): Promise<Server> {

  // Session setup (in-memory; data.db holds users)
  app.use(session({
    secret: "shapescan-secret-2026",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 7 * 24 * 60 * 60 * 1000 }, // 7 days
  }));

  // ── Auth Routes ────────────────────────────────────────────────────────────
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      if (!username || typeof username !== "string" || username.trim().length < 1) {
        return res.status(400).json({ error: "Username is required" });
      }
      // Password: at least 5 numeric digits
      if (!password || !/^\d{5,}$/.test(password)) {
        return res.status(400).json({ error: "Password must be at least 5 numeric digits (e.g. 12345)" });
      }
      const existing = await storage.getUserByUsername(username.trim().toLowerCase());
      if (existing) {
        return res.status(409).json({ error: "Username already taken" });
      }
      const user = await storage.createUser({
        username: username.trim().toLowerCase(),
        password,
        createdAt: Date.now(),
      });
      req.session.userId = user.id;
      req.session.username = user.username;
      return res.status(201).json({ id: user.id, username: user.username });
    } catch (e) {
      console.error("Register error:", e);
      return res.status(500).json({ error: "Failed to register" });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      const user = await storage.getUserByUsername((username || "").trim().toLowerCase());
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Invalid username or password" });
      }
      req.session.userId = user.id;
      req.session.username = user.username;
      return res.json({ id: user.id, username: user.username });
    } catch (e) {
      return res.status(500).json({ error: "Failed to login" });
    }
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.session.destroy(() => {
      res.json({ ok: true });
    });
  });

  app.get("/api/auth/me", (req: Request, res: Response) => {
    if (req.session?.userId) {
      return res.json({ id: req.session.userId, username: req.session.username });
    }
    return res.status(401).json({ error: "Not authenticated" });
  });

  // ── Projects ────────────────────────────────────────────────────────────────
  app.get("/api/projects", requireAuth, async (req: Request, res: Response) => {
    try { res.json(await storage.getAllProjects(req.session.userId!)); }
    catch { res.status(500).json({ error: "Failed to fetch projects" }); }
  });

  app.post("/api/projects", requireAuth, async (req: Request, res: Response) => {
    try {
      const body = insertProjectSchema.parse({
        name: req.body.name,
        userId: req.session.userId!,
        createdAt: Date.now(),
      });
      res.status(201).json(await storage.createProject(body));
    } catch (e) {
      if (e instanceof z.ZodError) res.status(400).json({ error: e.errors });
      else res.status(500).json({ error: "Failed to create project" });
    }
  });

  app.patch("/api/projects/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      res.json(await storage.renameProject(Number(req.params.id), req.session.userId!, req.body.name));
    } catch { res.status(500).json({ error: "Failed to rename project" }); }
  });

  app.delete("/api/projects/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      await storage.deleteProject(Number(req.params.id), req.session.userId!);
      res.json({ ok: true });
    } catch { res.status(500).json({ error: "Failed to delete project" }); }
  });

  // ── Shapes ──────────────────────────────────────────────────────────────────
  app.get("/api/shapes", requireAuth, async (req: Request, res: Response) => {
    try {
      const { projectId } = req.query;
      let filter: number | null | undefined = undefined;
      if (projectId === "null") filter = null;
      else if (projectId && !isNaN(Number(projectId))) filter = Number(projectId);
      res.json(await storage.getAllShapes(req.session.userId!, filter));
    } catch { res.status(500).json({ error: "Failed to fetch shapes" }); }
  });

  app.post("/api/shapes", requireAuth, async (req: Request, res: Response) => {
    try {
      const body = insertSavedShapeSchema.parse({
        name: req.body.name,
        vertices: req.body.vertices,
        projectId: req.body.projectId ?? null,
        userId: req.session.userId!,
        createdAt: Date.now(),
      });
      res.status(201).json(await storage.saveShape(body));
    } catch (e) {
      if (e instanceof z.ZodError) res.status(400).json({ error: e.errors });
      else res.status(500).json({ error: "Failed to save shape" });
    }
  });

  app.delete("/api/shapes/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      await storage.deleteShape(Number(req.params.id), req.session.userId!);
      res.json({ ok: true });
    } catch { res.status(500).json({ error: "Failed to delete shape" }); }
  });

  app.patch("/api/shapes/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      if (req.body.projectId !== undefined) {
        res.json(await storage.moveShape(Number(req.params.id), req.session.userId!, req.body.projectId));
      } else {
        res.json(await storage.updateShape(Number(req.params.id), req.session.userId!, req.body.name));
      }
    } catch { res.status(500).json({ error: "Failed to update shape" }); }
  });

  return _httpServer;
}
