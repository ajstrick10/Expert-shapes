import { savedShapes, projects, users } from '@shared/schema';
import type { SavedShape, InsertSavedShape, Project, InsertProject, User, InsertUser } from '@shared/schema';
import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { eq, desc, isNull, and } from "drizzle-orm";

const sqlite = new Database("data.db");
sqlite.pragma("journal_mode = WAL");

// ── Create / migrate tables ─────────────────────────────────────────────────
sqlite.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    created_at INTEGER NOT NULL
  )
`);

sqlite.exec(`
  CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    user_id INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  )
`);

sqlite.exec(`
  CREATE TABLE IF NOT EXISTS saved_shapes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    vertices TEXT NOT NULL,
    project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
    user_id INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  )
`);

// Migrate: add columns that may not exist on older databases
try { sqlite.exec(`ALTER TABLE projects ADD COLUMN user_id INTEGER NOT NULL DEFAULT 0`); } catch { /* exists */ }
try { sqlite.exec(`ALTER TABLE saved_shapes ADD COLUMN project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL`); } catch { /* exists */ }
try { sqlite.exec(`ALTER TABLE saved_shapes ADD COLUMN user_id INTEGER NOT NULL DEFAULT 0`); } catch { /* exists */ }

export const db = drizzle(sqlite);

// ── Interface ───────────────────────────────────────────────────────────────
export interface IStorage {
  // Auth
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(u: InsertUser): Promise<User>;
  // Projects
  getAllProjects(userId: number): Promise<Project[]>;
  createProject(p: InsertProject): Promise<Project>;
  renameProject(id: number, userId: number, name: string): Promise<Project | undefined>;
  deleteProject(id: number, userId: number): Promise<void>;
  // Shapes
  getAllShapes(userId: number, projectId?: number | null): Promise<SavedShape[]>;
  saveShape(shape: InsertSavedShape): Promise<SavedShape>;
  deleteShape(id: number, userId: number): Promise<void>;
  updateShape(id: number, userId: number, name: string): Promise<SavedShape | undefined>;
  moveShape(id: number, userId: number, projectId: number | null): Promise<SavedShape | undefined>;
}

export class DatabaseStorage implements IStorage {
  // ── Auth ──────────────────────────────────────────────────────
  async getUserByUsername(username: string): Promise<User | undefined> {
    return db.select().from(users).where(eq(users.username, username)).get();
  }
  async createUser(u: InsertUser): Promise<User> {
    return db.insert(users).values(u).returning().get();
  }

  // ── Projects ──────────────────────────────────────────────────
  async getAllProjects(userId: number): Promise<Project[]> {
    return db.select().from(projects)
      .where(eq(projects.userId, userId))
      .orderBy(desc(projects.createdAt)).all();
  }
  async createProject(p: InsertProject): Promise<Project> {
    return db.insert(projects).values(p).returning().get();
  }
  async renameProject(id: number, userId: number, name: string): Promise<Project | undefined> {
    return db.update(projects).set({ name })
      .where(and(eq(projects.id, id), eq(projects.userId, userId)))
      .returning().get();
  }
  async deleteProject(id: number, userId: number): Promise<void> {
    db.delete(projects)
      .where(and(eq(projects.id, id), eq(projects.userId, userId)))
      .run();
  }

  // ── Shapes ────────────────────────────────────────────────────
  async getAllShapes(userId: number, projectId?: number | null): Promise<SavedShape[]> {
    if (projectId === undefined) {
      return db.select().from(savedShapes)
        .where(eq(savedShapes.userId, userId))
        .orderBy(desc(savedShapes.createdAt)).all();
    }
    if (projectId === null) {
      return db.select().from(savedShapes)
        .where(and(eq(savedShapes.userId, userId), isNull(savedShapes.projectId)))
        .orderBy(desc(savedShapes.createdAt)).all();
    }
    return db.select().from(savedShapes)
      .where(and(eq(savedShapes.userId, userId), eq(savedShapes.projectId, projectId)))
      .orderBy(desc(savedShapes.createdAt)).all();
  }
  async saveShape(shape: InsertSavedShape): Promise<SavedShape> {
    return db.insert(savedShapes).values(shape).returning().get();
  }
  async deleteShape(id: number, userId: number): Promise<void> {
    db.delete(savedShapes)
      .where(and(eq(savedShapes.id, id), eq(savedShapes.userId, userId)))
      .run();
  }
  async updateShape(id: number, userId: number, name: string): Promise<SavedShape | undefined> {
    return db.update(savedShapes).set({ name })
      .where(and(eq(savedShapes.id, id), eq(savedShapes.userId, userId)))
      .returning().get();
  }
  async moveShape(id: number, userId: number, projectId: number | null): Promise<SavedShape | undefined> {
    return db.update(savedShapes).set({ projectId })
      .where(and(eq(savedShapes.id, id), eq(savedShapes.userId, userId)))
      .returning().get();
  }
}

export const storage = new DatabaseStorage();
